<?php 

    
    session_start();
    $host = "localhost";
    $user = "group16";
    $pass = "ourreveal";
    $dbname = "group16";

    if(!isset($_SESSION['access'])){
        $_SESSION['access'] = 0;
    }
      

    $connect = @mysqli_connect($host, $user, $pass, $dbname);
    
    if(mysqli_connect_errno()){
        die("connection error");
    }
?>