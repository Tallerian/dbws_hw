<?php 

    session_start();

    $host = "localhost";
    $_SESSION['user'] = "group16admin";
    $_SESSION['pass'] = "SupplyFill";
    $dbname = "group16";

    $connect = @mysqli_connect($host, $_SESSION['user'], $_SESSION['pass'], $dbname);
    
    if(mysqli_connect_errno()){
        die("connection error");
    }
?>