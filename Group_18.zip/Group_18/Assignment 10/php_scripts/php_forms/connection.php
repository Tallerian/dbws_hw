<?php
$serverName = "localhost";
$userName = "group18";
$password = "8dLvpK";
//$userName = "root";
//$password = "";
$dbName = "group18";

// create connection
$conn = mysqli_connect($serverName, $userName, $password, $dbName, 3308);


if (mysqli_connect_errno()) {
    echo "Failed to connect to DB!";
    exit();
}
