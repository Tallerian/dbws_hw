<?php
include '../php_forms/connection.php';
echo '<script>console.log("Your stuff here")</script>';


$searchTerm = $_GET['term'];
$sql = mysqli_query($conn, "SELECT * FROM books WHERE Title LIKE '%" . $searchTerm . "%'");
if ($sql) {
    $numOfRows = mysqli_num_rows($sql);
    if ($numOfRows > 0) {
        echo '<script>console.log("Your stuff here")</script>';
        while ($row = mysqli_fetch_assoc($sql)) {
            $bookTitles[] = $row['Title'];
            echo json_encode($bookTitles);
        }
    } else {
        // echo "Error during SQL querying: " . mysqli_error($conn) . "<br>";
        echo '<script>console.log("Your stuff here")</script>';
    }
}

// $select =mysql_query("SELECT * FROM coding_language WHERE name LIKE '%".$searchTerm."%'");
// while ($row=mysql_fetch_array($select)) 
// {
//  $data[] = $row['name'];
// }
//return json data
echo json_encode($data);
