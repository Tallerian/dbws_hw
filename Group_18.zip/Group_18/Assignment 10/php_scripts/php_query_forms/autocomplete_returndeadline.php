<?php
include '../php_forms/connection.php';
// echo '<script>console.log("Your stuff here")</script>';

$searchText = $_POST['search'];
// $searchText = "15";
if (!empty($searchText)) {
    $sql = "SELECT ReturnDeadline FROM borrowed_entries WHERE ReturnDeadline LIKE '%" . $searchText . "%' order by ReturnDeadline  asc limit 7";
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        printf("Error: %s\n", mysqli_error($conn));
        exit();
    }
    $search_arr = array();

    while ($row = mysqli_fetch_array($result)) {
        $search_arr[] = array("label" => $row['ReturnDeadline']);
        // $search_arr[] = array($row['Title']);
    }

    echo json_encode($search_arr);
    // print_r($search_arr);
}
