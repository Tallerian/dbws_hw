<?php include '../php_forms/connection.php'; ?>
<!DOCTYPE html>
<html lang="en">

<?php
// Initialize the session
session_start();
$isLoggedIn;
$isAdmin = $_SESSION["isAdmin"];
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $isAdmin == 0) {
    if ($isAdmin == 0) {
        header("location: ../php_forms/access_denied.php");
        exit;
    } else {
        $isLoggedIn = false;
        header("location: ../php_forms/login_form.php");
        exit;
    }
} else {
    $isLoggedIn = true;
}
?>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LMDBS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../styles.css" />
    <link rel="stylesheet" href="./query.styles.css" />
</head>

<body>
    <div class="block block--metabar">
        <!-- Below it says "navbar" but really, its the metabar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="./index.php">
                <img src="../../img/logo.png" alt="website-logo" class="image image--navbarLogo">
                <div class="navbar--divider"></div>
            </a>
            <div class="block block--metabarGroup">
                <a class="nav-item nav-link" href="../php_forms/signup_form.php">Sign Up</a>
                <?php
                if ($isLoggedIn) {
                    echo "<a class='nav-item nav-link' href='../php_forms/logout_form.php'>Logout</a>";
                } else {
                    echo "<a class='nav-item nav-link' href='../php_forms/login_form.php'>Login</a>";
                }
                ?>
            </div>
        </nav>
    </div>

    <div class="block block--outer">
        <!-- below it says sidebar, but this is actually the navigation bar as
      mentioned in the CD -->
        <div class="block block--sidebar">
            <a href="../../index.php" class="button--sidebar">
                <i class="fas fa-home"></i>
                <h2>Home</h2>
            </a>
            <a href="../../map.php" class="button--sidebar">
                <i class="fas fa-map-marked-alt"></i>
                <h2>Map</h2>
            </a>
            <a href="../../contact.php" class="button--sidebar">
                <i class="fas fa-phone"></i>
                <h2>Contact</h2>
            </a>
            <a href="../../imprint.php" class="button--sidebar">
                <i class="fas fa-info-circle"></i>
                <h2>Imprint</h2>
            </a>
            <a href="../../maintain.php" class="button--sidebar">
                <i class="fas fa-tools"></i>
                <h2>Maintain</h2>
            </a>
            <a href="../../search_forms.php" class="button--sidebar current">
                <i class="fas fa-search"></i>
                <h2>Search</h2>
            </a>
        </div>

        <div class="block block--mainContentWrapper book-query">
            <div class="block block--mainContent search-query">
                <h1 class="header header--welcome">Search User</h1>
                <div class="block block--searchBarInputGroup">
                    <form class="form form--searchbar form-inline" method="POST">
                        <input class="form-control mr-sm-2 input--searchbar" type="text" placeholder="Search User" aria-label="Search" name="search">
                        <button class="btn btn-outline-success my-2 my-sm-0 button--searchbar" type="submit" name="submit-search">Search</button>
                    </form>
                </div>
                <a href="../../search_forms.php" style="font-size: 16px; margin-top: 20px;">Go back to search forms</a>
            </div>
            <h3>Search results: </h3>
            <div class='block block--books-container'>
                <?php
                if (isset($_POST['submit-search'])) {
                    $search = mysqli_real_escape_string($conn, $_POST['search']);
                    //modified prepared statements 93-105
                    $sql = "SELECT * FROM user WHERE UserName LIKE CONCAT('%',?,'%');";
                    $stmt= mysqli_stmt_init($conn);
                    if(!mysqli_stmt_prepare($stmt, $sql)){
                        echo "SQL query failed";
                    } else {
                        //bind params into database
                        mysqli_stmt_bind_param($stmt, "s", $search);
                        //run params into db
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);
                        $queryResults = mysqli_num_rows($result);
                    }

                    if ($queryResults > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $UserID = $row['UserID'];
                            echo "
                            <a href='./user_result_page.php?userID=$UserID' method='get'>
                            
                                <div class='block--user-result'>
                                    <h3> " . $row['UserName'] . "</h3>
                                </div>
                            </a>";
                        }
                    } else {
                        echo "There are no results matching your search term!";
                    }

                    // echo "Hello world";
                }

                // !!!! Below code is to print all users (don't remove the following code in comments) !!!!

                // $sql_title = "SELECT * FROM user";
                // $result = mysqli_query($conn, $sql_title);
                // $queryResults = mysqli_num_rows($result);

                // if ($queryResults > 0) {
                //     while ($row = mysqli_fetch_assoc($result)) {
                //         echo "<div class='block--user-result'>
                //         <h3>" . $row['UserID'] . "</h3>
                //         <h3>" . $row['UserName'] . "</h3>
                //     </div>";
                //     }
                // }

                ?>
            </div>

        </div>
    </div>

</body>

</html>