<!DOCTYPE html>
<html lang="en">

<?php
// Initialize the session
session_start();
$isLoggedIn;
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    $isLoggedIn = false;
    header("location: ./php_scripts/php_forms/login_form.php");
    exit;
} else {
    $isLoggedIn = true;
}
?>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LMDBS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="./styles.css" />
</head>

<body>
    <div class="block block--metabar">
        <!-- Below it says "navbar" but really, its the metabar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="./index.php">
                <img src="./img/logo.png" alt="website-logo" class="image image--navbarLogo">
                <div class="navbar--divider"></div>
            </a>
            <div class="block block--metabarGroup">
                <a class="nav-item nav-link" href="./php_scripts/php_forms/signup_form.php">Sign Up</a>
                <?php
                if ($isLoggedIn) {
                    echo "<a class='nav-item nav-link' href='./php_scripts/php_forms/logout_form.php'>Logout</a>";
                } else {
                    echo "<a class='nav-item nav-link' href='./php_scripts/php_forms/login_form.php'>Login</a>";
                }
                ?>
                <!-- <a class="nav-item nav-link" href="./php_scripts/php_forms/login_form.php">Login</a> -->
            </div>
        </nav>
    </div>

    <div class="block block--outer">
        <!-- below it says sidebar, but this is actually the navigation bar as
      mentioned in the CD -->
        <div class="block block--sidebar">
            <a href="./index.php" class="button--sidebar">
                <i class="fas fa-home"></i>
                <h2>Home</h2>
            </a>
            <a href="./map.php" class="button--sidebar">
                <i class="fas fa-map-marked-alt"></i>
                <h2>Map</h2>
            </a>
            <a href="./contact.php" class="button--sidebar">
                <i class="fas fa-phone"></i>
                <h2>Contact</h2>
            </a>
            <a href="./imprint.php" class="button--sidebar">
                <i class="fas fa-info-circle"></i>
                <h2>Imprint</h2>
            </a>
            <a href="./maintain.php" class="button--sidebar">
                <i class="fas fa-tools"></i>
                <h2>Maintain</h2>
            </a>
            <a href="./search_forms.php" class="button--sidebar current">
                <i class="fas fa-search"></i>
                <h2>Search</h2>
            </a>
        </div>

        <div class="block block--mainContent search">
            <!-- Insert links here, for example -->
            <!-- small tip for vs code, move type cursor inside href string, and press
             ctrl + spacebar, it will show you file directory popup menu-->
            <!--please add new php search forms inside the php_qery_forms folder -->
            <div class="block book-title-search-form">
                <a href="./php_scripts/php_query_forms/book_title_search_query.php">Search books by title</a>
            </div>
            <div class="block book-author-search-form">
                <a href="./php_scripts/php_query_forms/book_author_search_query.php">Search books by author</a>
            </div>
            <a href="./php_scripts/php_query_forms/user_search_query.php">Search Users by User Name</a>
            <a href="./php_scripts/php_query_forms/order_returnDeadline_search_query.php">Search Orders by Return
                Deadline</a>
        </div>
    </div>

</body>

</html>