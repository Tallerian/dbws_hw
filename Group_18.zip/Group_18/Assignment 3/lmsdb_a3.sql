CREATE DATABASE `lmsdbcity` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

/*If you run into the following error: "Unknown collation: utf8mb4_unicode_ci", then replace (ctrl+r) all instances of
"utf8mb4_unicode_ci" to "utf8mb4_unicode_520_ci" This error can occur as a result of old mysql server instances and depends on the machine.
Since clamV service was down, there was no way to test which of these 2 options would be compatible with clamV*/

/*In this script, ISA relationships have been made using the following command:
  {subclass_id} int PRIMARY KEY REFERENCES {superclass_table_name} ({super_class_primary_key})
*/

CREATE TABLE `authentication` (
  `AuID` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(45) NOT NULL UNIQUE,
  `Password` varchar(45) NOT NULL,
  PRIMARY KEY (`AuID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='holds all the authentication data (password, email) of normalusers and librarian staff members';

CREATE TABLE `user` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `UserName` varchar(60) NOT NULL,
  `IsAdmin` tinyint(1) NOT NULL,
  `AuID` int DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  KEY `AuID_idx` (`AuID`),
  CONSTRAINT `AuID` FOREIGN KEY (`AuID`) REFERENCES `authentication` (`AuID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='This is the superclass that holds all the user sub-classes';

CREATE TABLE `books` (
  `BookID` int NOT NULL,
  `Edition` int DEFAULT '1',
  `PublisherName` varchar(60) DEFAULT NULL,
  `Title` varchar(60) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `ImageURL` varchar(45) DEFAULT NULL,
  `Author` varchar(45) NOT NULL,
  `ISBN` bigint NOT NULL UNIQUE,
  `CopiesAvailable` int DEFAULT '1',
  PRIMARY KEY (`BookID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='contains all the physical books owned by the library. This is also a superclass for "novels" and "coursebooks" subclasses.';

CREATE TABLE `borrowed_entries` (
  BorrowedEntryID int PRIMARY KEY REFERENCES order_entry (OrderID),
  `LentBy` varchar(60) NOT NULL,
  `ReturnDeadline` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='subclass that inherits from "order_entry". Keeps track of all books that have been returned by "normalusers".';

CREATE TABLE `coursebooks` (
  CoursebookID int PRIMARY KEY REFERENCES books (BookID),
  `Subject` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='subclass inherits from "books" superclass. Contains all coursebooks.';

CREATE TABLE `facultymember` (
  FacultyMemberID int PRIMARY KEY REFERENCES normal_user (NormalUserID),
  `faculty_number` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `librarian` (
  LibrarianID int PRIMARY KEY REFERENCES user (UserID),
  `BooksRecieved` int NOT NULL DEFAULT '0',
  `BooksLent` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `normal_user` (
  NormalUserID int PRIMARY KEY REFERENCES user (UserID),
  `BooksTaken` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='subclass which inherits from "user". It is also a subclass for the "student" and "facultymember" tables';

CREATE TABLE `novel` (
  NovelID int PRIMARY KEY REFERENCES books (BookID),
  `Genre` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='subclass inherits from "books" superclass. Contains all non-coursebooks';

CREATE TABLE `order_entry` (
  `OrderID` int NOT NULL AUTO_INCREMENT,
  `BookID` int NOT NULL,
  `UserID` int NOT NULL,
  `DateIssued` date DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `BookID_idx` (`BookID`),
  KEY `UserID_idx` (`UserID`),
  CONSTRAINT `BookID` FOREIGN KEY (`BookID`) REFERENCES `books` (`BookID`),
  CONSTRAINT `UserID` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='this is a superclass for "returned" and "borrowed" order entry subclasses, to keep track of all the books borrowed and received';

CREATE TABLE `returned_entries` (
  ReturnedEntryID int PRIMARY KEY REFERENCES order_entry (OrderID),
  `ReturnDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='subclass that inherits from "order_entry". Keeps track of all books that have been returned by "normalusers".';

CREATE TABLE `student` (
  StudentID int PRIMARY KEY REFERENCES normal_user (NormalUserID),
  `matriculation_number` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
