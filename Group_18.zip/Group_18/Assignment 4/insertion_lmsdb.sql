-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 03, 2021 at 12:21 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+01:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group18`
--

--
-- Dumping data for table `authentication`
--

INSERT INTO `authentication` (`AuID`, `Email`, `Password`) VALUES
(1, 'dumbdata@donotusetologin', '12345'),
(2, 'dumbdata1@donotusetologin', '12345'),
(3, 'dumbdata2@do-not-use-to-login', '12345'),
(4, 'dumbdata3@please-make-a-new-user', '12345');

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `IsAdmin`, `AuID`) VALUES
(1, 'librarian-1', 1, 1),
(2, 'librarian-2', 1, 2),
(3, 'normal-user-1', 0, 3),
(4, 'normal-user-2', 0, 4);
COMMIT;


--
-- Dumping data for table `books`
--



INSERT INTO `books` (`BookID`, `Edition`, `PublisherName`, `Title`, `Description`, `ImageURL`, `Author`, `ISBN`, `CopiesAvailable`) VALUES
(1, 2, 'New York Times', 'SQL Mastery', 'From beginner to hero level with just one book', '#fjfldj', 'Peter Baumann', 11112222, 2),
(2, 1, 'New York Times', 'Operating system', 'develop your own Operating system', '#fjfldj', 'Alice', 11112223, 3),
(3, 3, 'BBBBBB', 'some random novel', 'only if do not understand anything', '#fjfldj', 'Jane', 11112224, 1),
(4, 4, 'JK Rowling', 'Harry Potter', 'Welcome to Hogwart', '#fjfldj', 'Jane', 11112225, 5),
(5, 5, 'JK Rowling', 'Harry Potter Part 2', 'Welcome to Hogwart', '#fjfldj', 'Jane', 11112226, 0),
(6, 3, 'NY Times', 'Harry Potter 4', 'This is a teast.', 'https://images-eu.ssl-images-amazon.com/images/I/5160dwNeqSL._SY264_BO1,204,203,200_QL40_ML2_.jpg', 'JK Rowling', 19231321321, 2),
(7, 3, 'NY Times', 'Charlie and The Chocolate Factory', 'Early Years', 'https://assets.thalia.media/img/artikel/bebe20b87ba0c563eb099810df2526acbb75cb3c-00-00.jpeg', 'Roald Dahl', 23177678999122, 3),
(8, 4, 'NYTIMES', 'Matilda', 'Early Years', 'https://images-na.ssl-images-amazon.com/images/I/51vHLdb4CYL._SX323_BO1,204,203,200_.jpg', 'Roald Dahl', 9756788652, 2),
(9, 3, 'NYTIMES', 'The BFG', 'Early Years', 'https://m.media-amazon.com/images/I/91blJEoDdcL._SY445_.jpg', 'Roald Dahl', 4545454545, 8),
(10, 7, 'NYTIMES', 'The Witches', 'Early Years', 'https://images-na.ssl-images-amazon.com/images/I/51bDl2ipY2S._SX324_BO1,204,203,200_.jpg', 'Roald Dahl', 6755756868, 2),
(11, 3, 'Penguin House', 'Angels and Demons', 'Adult', 'https://pictures.abebooks.com/isbn/9780743493468-de.jpg', 'Dan Brown', 9876788723, 10),
(12, 4, 'Penguin House', 'The Da Vinci Code', 'Adult', 'https://pictures.abebooks.com/isbn/9780743493468-de.jpg', 'Dan Brown', 99999993333, 6),
(13, 3, 'Princeton Review', 'Organic Chemistry', 'academic', 'https://images-na.ssl-images-amazon.com/images/I/41zra39zWxL._SY445_SX342_QL70_FMwebp_.jpg', 'David Klein', 999899888898, 4),
(14, 6, 'Princeton Review', 'Inorganic Chemistry', 'academic', 'https://images-na.ssl-images-amazon.com/images/I/51oZrHb+D7L._SX395_BO1,204,203,200_.jpg', 'David Klein', 7272727727, 6),
(15, 2, 'Princeton Review', 'Think Python', 'academic', 'https://images-eu.ssl-images-amazon.com/images/I/51yWKSfOcfS._SX198_BO1,204,203,200_QL40_ML2_.jpg', 'O Reilly', 65675656333, 2),
(16, 3, 'Princeton Review', 'JavaScript Patterns', 'academic', 'https://images-na.ssl-images-amazon.com/images/I/51PKxi4d03S._SX379_BO1,204,203,200_.jpg', 'O Reilly', 7272727898989, 3);



--
-- Dumping data for table `order_entry`
--

INSERT INTO `order_entry` (`OrderID`, `BookID`, `UserID`, `DateIssued`) VALUES
(1, 1, 3, '2021-10-09'),
(2, 3, 4, '2021-10-04'),
(3, 1, 3, '2021-09-14'),
(4, 4, 4, '2021-10-02'),
(5, 16, 2, '2021-10-15'),
(6, 8, 1,  '2021-10-15'),
(7, 11,3, '2021-11-15'),
(8, 12,2, '2021-11-15'),
(9, 13,1, '2021-12-5'),
(10, 14,4, '2021-11-5'),
(11, 15,3, '2021-11-10');
--
-- Dumping data for table `borrowed_entries`
--

INSERT INTO `borrowed_entries` (`BorrowedEntryID`, `ReturnDeadline`) VALUES
(1, '2021-10-15'),
(2, '2021-10-12'),
(5, '2021-10-30'),
(6,'2021-10-30'),
(7, '2021-10-30'),
(8, '2021-11-30'),
(9, '2021-12-15'),
(10,'2021-11-15'),
(11,'2021-11-20');
--
-- Dumping data for table `coursebooks`
--

INSERT INTO `coursebooks` (`CoursebookID`, `Subject`) VALUES
(1, 'Database Design'),
(2, 'Operating Systems'),
(13, 'Chemistry'),
(14, 'Chemistry'),
(15, 'Computer Science'),
(16, 'Computer Science');


--
-- Dumping data for table `normal_user`
--

INSERT INTO `normal_user` (`NormalUserID`, `BooksTaken`) VALUES
(3, 2),
(4, 5);

--
-- Dumping data for table `facultymember`
--

INSERT INTO `facultymember` (`FacultyMemberID`, `faculty_number`) VALUES
(4, 4000295);

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`LibrarianID`, `BooksReceived`, `BooksLent`) VALUES
(1, 10, 20),
(2, 4, 9);



--
-- Dumping data for table `novel`
--

INSERT INTO `novel` (`NovelID`, `Genre`) VALUES
(3, 'adventure'),
(4, 'fantasy'),
(5, 'fantasy'),
(6, 'Fantasy'),
(7, 'Fantasy'),
(8, 'Fantasy'),
(9, 'Fantasy'),
(10, 'Fantasy'),
(11, 'Mystery'),
(12, 'Mystery');



--
-- Dumping data for table `returned_entries`
--

INSERT INTO `returned_entries` (`ReturnedEntryID`, `ReturnDate`) VALUES
(3, '2021-10-01'),
(4, '2021-10-03');

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`StudentID`, `matriculation_number`) VALUES
(3, 2000238);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
