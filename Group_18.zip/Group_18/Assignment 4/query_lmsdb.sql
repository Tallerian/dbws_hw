USE group18;
-- Selection of books by Publisher Name 
SELECT books.Title as "Book Title", books.Author, books.PublisherName
FROM books
WHERE books.PublisherName= "New York Times";

-- Getting book’s name ordered by the date it was issued 
SELECT order_entry.BookID, order_entry.DateIssued, books.Title
FROM order_entry
INNER JOIN books ON order_entry.BookID = books.BookID
ORDER BY order_entry.OrderID;

-- Grouping novel by genres
SELECT books.Title, novel.Genre
FROM novel
INNER JOIN books ON books.BookID = novel.NovelID
GROUP BY novel.Genre; 

-- Aggregate Function used: Sum
-- Adding the number of books by certain author
SELECT COUNT(books.Author)
FROM books
WHERE books.Author="Jane";

-- Aggregate func + Grouby 
-- Returns number of books for each subject
SELECT Subject, COUNT(*)
FROM coursebooks
GROUP BY coursebooks.Subject;

-- Displays users (and their UserID) that have taken more than 3 books
SELECT
user.UserName,
user.UserID,
normal_user.BooksTaken
FROM user
INNER JOIN normal_user
ON user.UserID = normal_user.NormalUserID
WHERE normal_user.BooksTaken > 3;

-- Displays all novels, and their genres in the database
SELECT
books.BookID,
books.Title,
books.Description,
books.Author,
books.ISBN,
novel.Genre
FROM books
INNER JOIN novel
ON books.BookID = novel.NovelID
ORDER BY books.BookID;

-- Shows all authentication rows
SELECT * FROM Authentication;

-- Displays all borrowed books order entries
SELECT
borrowed_entries.BorrowedEntryID,
order_entry.DateIssued,
borrowed_entries.ReturnDeadline
FROM order_entry
INNER JOIN borrowed_entries
ON order_entry.OrderID = borrowed_entries.BorrowedEntryID
ORDER BY order_entry.OrderID;

-- Show books which have at least one copy available
SELECT books.Title, books.Author, books.Description, books.ISBN, books.copiesAvailable
FROM books
WHERE books.copiesAvailable > 0;

-- List all the librarians which have added books to the system
SELECT user.UserName, user.UserID, librarian.BooksReceived
FROM user
INNER JOIN librarian
ON user.UserId = librarian.LibrarianID
WHERE librarian.BooksReceived > 0;

-- Display list of all the users who have borrowed exactly 2 books
SELECT user.UserName, user.UserID, normal_user.BooksTaken
FROM user
INNER JOIN normal_user
on user.UserID=normal_user.NormalUserID
WHERE normal_user.BooksTaken=2;