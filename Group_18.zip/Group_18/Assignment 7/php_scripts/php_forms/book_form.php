<?php include './connection.php'; ?>
<html>

<head>
  <title>"Viola!"</title>
</head>
<style>
  #novel:checked~.novel {
    display: block;
  }

  #coursebook:checked~.coursebook {
    display: block;
  }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
  function firstCheckBox() {
    console.log("clicked checkbox!");
    $("#normal_user_form").toggle(400);
    // $("#submit1").toggle(400);
  }

  $(document).ready(function() {
    console.log("ready!");
    $("#coursebook_input").prop('required', true);
    $("#genre_input").prop('required', false);
  });


  function firstRadioButton() {
    console.log("clicked 1st radio button");
    $("#student_form").show();
    $("#faculty_member_form").hide();
    $("#coursebook_input").prop('required', true);
    $("#genre_input").prop('required', false);
  }

  function secondRadioButton() {
    console.log("clicked 2nd radio button");
    $("#student_form").hide();
    $("#faculty_member_form").show();
    $("#genre_input").prop('required', true);
    $("#coursebook_input").prop('required', false);
  }
</script>

<body>
  <form method="post">
    <label>Title</label>
    <input type="text" name="Title" required> <br>
    <label>Author</label>
    <input type="text" name="Author" required> <br>
    <label>Publisher name</label>
    <input type="text" name="PublisherName" required> <br>
    <label>Book Description</label>
    <input type="text" name="Description" required> <br>
    <label>Book Edition</label>
    <input type="number" name="Edition" required> <br>
    <label>ISBN</label>
    <input type="number" name="ISBN" required> <br>
    <label>Copies Available</label>
    <input type="number" name="CopiesAvailable" required> <br>
    <label>Image URL</label>
    <input type="url" name="ImageURL"><br>
    <p>Select any of the following book type:</p>

    <input type="radio" checked name="booktype" id="coursebook" value="coursebook" onclick="firstRadioButton()">
    <label for=" coursebook">coursebook</label> <br>
    <input type="radio" name="booktype" id="novel" value="novel" onclick="secondRadioButton()">
    <label for=" novel">novel</label>
    <div class="novel" hidden>
      <input id="genre_input" type="text" name="genre" placeholder="Enter Genre" required />
    </div>
    <div class="coursebook" hidden>
      <input id="coursebook_input" type="text" name="subject" placeholder="Enter Subject" required />
    </div>
    <input type="submit" name="submit">
  </form>
  </form>

  <?php
  if (isset($_POST["submit"])) {
    $title = $_POST["Title"];
    $author = $_POST["Author"];
    $edition = $_POST["Edition"];
    $publisher = $_POST["PublisherName"];
    $copies = $_POST["CopiesAvailable"];
    $isbn = $_POST["ISBN"];
    $url = $_POST["ImageURL"];
    $description = $_POST["Description"];
    $genre = $_POST["genre"];
    $subject = $_POST["subject"];

    $sql = " INSERT INTO books (Title, Author, Edition,PublisherName, CopiesAvailable,ISBN,ImageURL, Description) VALUES('$title', '$author','$edition','$publisher',$copies,$isbn,'$url','$description')";
    if (mysqli_query($conn, $sql)) {
      echo ("Record addded successfully!" . "<br>");
    } else {
      echo "Error when inserting into books: " . mysqli_error($conn) . "<br>";
    }

    $maxBookIDQuery = mysqli_query($conn, "SELECT MAX( `BookID` ) FROM `books`");
    $BookID;
    while ($row = $maxBookIDQuery->fetch_assoc()) {
      foreach ($row as $value) {
        if ($value == NULL) {
          echo "NULL in User table" . "<br>";
          $BookID = 1;
        } else {
          $BookID = $value;
          // printf("AuID is NOT NULL: " . $AuID . "\n");
        }
      }
    }

    $radioVal = $_POST['booktype'] ?? NULL;
    if ($radioVal == "coursebook") {
      echo "You chose the first button" . "<br>";
      echo "Subject: " . $subject . "<br>";
      $sql_coursebook = "INSERT INTO coursebooks(CoursebookID, Subject) VALUES($BookID, '$subject')";
      if (mysqli_query($conn, $sql_coursebook)) {
        echo ("Record addded successfully!" . "<br>");
      } else {
        echo "Error when inserting into Coursebook: " . mysqli_error($conn) . "<br>";
      }
    } else if ($radioVal == "novel") {
      echo "You chose the second radio button" . "<br>";
      echo "Genre: " . $genre . "<br>";
      $sql_genre = "INSERT INTO novel(NovelID, Genre) VALUES($BookID, '$genre')";
      if (mysqli_query($conn, $sql_genre)) {
        echo ("Record addded successfully!" . "<br>");
      } else {
        echo "Error when inserting into Genre: " . mysqli_error($conn) . "<br>";
      }
    }
  }

  ?>

  <div style="display: flex; column-gap: 60px; row-gap: 30px; flex-wrap: wrap;">
    <div id="books-table">
      <h2>"Books" table values are</h2>
      <table border="1">
        <tr>
          <th>Title</th>
          <th>Author</th>
          <th>Publisher Name</th>
          <th>ISBN</th>
          <th>Edition</th>
          <th>Copies Available</th>
          <th>Description</th>
          <th>Image URL</th>

        </tr>
        <?php
        $conn;
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT * FROM books";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          // output data of each row
          while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["Title"] . "</td><td>" . $row["Author"] . "</td><td>" . $row["PublisherName"] . "</td><td>" . $row["ISBN"] . "</td><td>" . $row["Edition"] . "</td><td>" . $row["CopiesAvailable"] . "</td><td>" . $row["Description"] . "</td><td>" . $row["ImageURL"] . "</td></tr>";
          }
          echo "</table>";
        } else {
          echo "0 results";
        }
        // $conn->close();
        ?>
      </table>
    </div>

    <div id="novel">
      <h2>"novel" table values are</h2>
      <table border="1">
        <tr>
          <th>NovelID</th>
          <th>Genre</th>
        </tr>
        <?php
        $sql = "SELECT * FROM novel";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          // output data of each row
          while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["NovelID"] . "</td><td>" . $row["Genre"] . "</td></tr>";
          }
          echo "</table>";
        } else {
          echo "0 results";
        }
        // $conn->close();
        ?>
      </table>
    </div>

    <div id="coursebooks-table">
      <h2>"coursebooks" table values are</h2>
      <table border="1">
        <tr>
          <th>CoursebookID</th>
          <th>Subject</th>
        </tr>
        <?php
        // $conn;
        // // Check connection
        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }
        $sql = "SELECT * FROM coursebooks";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          // output data of each row
          while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["CoursebookID"] . "</td><td>" . $row["Subject"] . "</td></tr>";
          }
          echo "</table>";
        } else {
          echo "0 results";
        }
        // $conn->close();
        ?>
      </table>
    </div>
  </div>
  <br><br><br><a href="../../maintain.html">Go back to maintainence page</a><br> <br>

</body>

</html>
