<html>

<head>
    <title>Hello World</title>
</head>

<body>

    <form method="post">
        <label>User Name</label>
        <input type="text" name="userName">
        <label>Are you an admin?</label>
        <input type="checkbox" name="isAdmin">
        <input type="submit" name="submit">
    </form>

    <a href="../../maintain.html">Go back to maintainence page</a><br> <br>

</body>

</html>

<?php
    $serverName = "localhost";
    $userName = "root";
    $password = "";
    $dbName = "lmsdb";

    // create connection
    $conn = mysqli_connect($serverName, $userName, $password, $dbName, 3308);

    if(mysqli_connect_errno()) {
        echo "Failed to connect to DB!";
        exit();
    }

    if(isset($_POST["submit"])){
        $userName = $_POST["userName"];
        $isAdmin = $_POST["isAdmin"];
        // The following has been implemented so that we can find out the last added AuID 
        // primary key in the authentication table, and make current user's AuID foreign 
        // key take that last added AuID
        $maxAuIDQuery = mysqli_query($conn, "SELECT MAX( `AuID` ) FROM `authentication`");
        // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
        while ($row = $maxAuIDQuery->fetch_assoc())
        {
            foreach($row as $value) $AuID = $value;
        }
        printf("AuID is: %d\n", $AuID);
        
        $sql = "INSERT INTO lmsdb.user(`UserName`, `IsAdmin`, `AuID`) VALUES ('$userName', '$isAdmin', $AuID)";

        if(mysqli_query($conn, $sql)) {
            echo ("Record addded successfully!");
        } else {
            echo ("Error when inserting: " . mysqli_error($conn));
        }
    }
?>