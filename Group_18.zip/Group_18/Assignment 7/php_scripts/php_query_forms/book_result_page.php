<?php include '../php_forms/connection.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LMDBS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../styles.css" />
    <link rel="stylesheet" href="./query.styles.css" />
</head>

<body>
    <?php
    $bookid = $_GET['bookID'];
    // $search = mysqli_real_escape_string($conn, $_POST['search']);
    $sql = "SELECT * FROM books WHERE BookID=$bookid";
    // $sql = "SELECT * FROM books WHERE Title LIKE '%$search%' OR Author LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);
    $queryResults = mysqli_num_rows($result);
    if ($queryResults > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $Title = $row['Title'];
            $ISBN = $row['ISBN'];
            $Author = $row['Author'];
            $Edition = $row['Edition'];
            $PublisherName = $row['PublisherName'];
            $ImageURL = $row['ImageURL'];
            $Description = $row['Description'];
            //  $genre=$row['genre'];
            //  $subject=$row['subject'];
            $copies = $row['CopiesAvailable'];
        }
    }
    ?>

    <div class="block block--metabar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="../../index.html">
                <img src="../../img/logo.png" alt="website-logo" class="image image--navbarLogo">
                <div class="navbar--divider"></div>
            </a>
            <div class="block block--metabarGroup">
                <a class="nav-item nav-link" href="#">Sign Up</a>
                <a class="nav-item nav-link" href="#">Login</a>
            </div>
        </nav>
    </div>

    <div class="block block--outer">
        <div class="block block--sidebar">
            <!-- <div class="button--sidebar"> -->
            <a href="../../index.html" class="button--sidebar">
                <i class="fas fa-home"></i>
                <h2>Home
                </h2>
            </a>
            <!-- </div> -->
            <a href="#" class="button--sidebar">
                <i class="fas fa-book"></i>
                <h2>Books</h2>
            </a>
            <a href="../../contact.html" class="button--sidebar">
                <i class="fas fa-phone"></i>
                <h2>Contact</h2>
            </a>
            <a href="../../imprint.html" class="button--sidebar">
                <i class="fas fa-info-circle"></i>
                <h2>Imprint</h2>
            </a>
            <a href="../../maintain.html" class="button--sidebar">
                <i class="fas fa-tools"></i>
                <h2>Maintain</h2>
            </a>
            <a href="../../search_forms.html" class="button--sidebar current">
                <i class="fas fa-search"></i>
                <h2>Search</h2>
            </a>
        </div>

        <div class="block block--mainContentWrapper result-page" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
            <div class="detail_container single_product">
                <div class="detail_row">
                    <div class="column-2">
                        <?php echo "<img src='" . $ImageURL . "' alt='img' style='height: 500px;'>" ?>
                        <!-- <img class="result-book-image" src=<?php $ImageURL; ?> alt="img" width="100%" /> -->
                    </div>
                    <div class="column-2">
                        <h1><?php echo "$Title"; ?></h1>
                        <p>Written by <?php echo "$Author"; ?></p>
                        <!-- <h4>Expected Price: {priceRange}</h4> -->
                        <a href="./book_title_search_query.php">
                            <button class="detail_button">
                                Back to search
                            </button>
                        </a>
                        <button class="detail_button">
                            Borrow book
                        </button class="detail_button">
                        <h3>Book Detail</h3>
                        <p><?php echo "$Description"; ?></p>
                        <br />
                        <!-- <br/> -->
                        <h5>Edition</h5>
                        <p>
                            <?php echo "$Edition"; ?>
                        </p>
                        <h5>Publisher name</h5>
                        <p>
                            <?php echo "$PublisherName"; ?>
                        </p>

                        <h5>ISBN</h5>
                        <p>
                            <?php echo "$ISBN"; ?>
                        </p>
                        <h5>Copies Available</h5>
                        <p>
                            <?php echo "$copies"; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>