<?php include '../php_forms/connection.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LMDBS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../styles.css" />
    <link rel="stylesheet" href="./query.styles.css" />
    <link rel="stylesheet" href="./user_result_page.css" />
</head>

<body>
    <?php
    $userID = $_GET['userID'];
    //$userID = 3;  
    // default for testing purpose

    // $search = mysqli_real_escape_string($conn, $_POST['search']);
    $sql_1 = "SELECT * FROM authentication WHERE AuID=3";
    $sql_2 = "SELECT * FROM normal_user WHERE NormalUserID=$userID";
    $sql_3 = "SELECT * FROM user WHERE userID=$userID";


    $result = mysqli_query($conn, $sql_1);
    $queryResults = mysqli_num_rows($result);
    if ($queryResults > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $Email = $row['Email'];
        }
    }

    $result = mysqli_query($conn, $sql_2);
    $queryResults = mysqli_num_rows($result);
    $isNormalUser = 0;
    if ($queryResults > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $BooksTaken = $row['BooksTaken'];
            $isNormalUser = 1;
        }
    }

    $result = mysqli_query($conn, $sql_3);
    $queryResults = mysqli_num_rows($result);
    if ($queryResults > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $UserName = $row['UserName'];
        }
    }


    ?>
    <div class="block block--metabar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="../../index.html">
                <img src="../../img/logo.png" alt="website-logo" class="image image--navbarLogo">
                <div class="navbar--divider"></div>
            </a>
            <div class="block block--metabarGroup">
                <a class="nav-item nav-link" href="#">Sign Up</a>
                <a class="nav-item nav-link" href="#">Login</a>
            </div>
        </nav>
    </div>

    <div class="block block--outer">
        <div class="block block--sidebar">
            <!-- <div class="button--sidebar"> -->
            <a href="../../index.html" class="button--sidebar">
                <i class="fas fa-home"></i>
                <h2>Home
                </h2>
            </a>
            <!-- </div> -->
            <a href="#" class="button--sidebar">
                <i class="fas fa-book"></i>
                <h2>Books</h2>
            </a>
            <a href="../../contact.html" class="button--sidebar">
                <i class="fas fa-phone"></i>
                <h2>Contact</h2>
            </a>
            <a href="../../imprint.html" class="button--sidebar">
                <i class="fas fa-info-circle"></i>
                <h2>Imprint</h2>
            </a>
            <a href="../../maintain.html" class="button--sidebar">
                <i class="fas fa-tools"></i>
                <h2>Maintain</h2>
            </a>
            <a href="../../search_forms.html" class="button--sidebar current">
                <i class="fas fa-search"></i>
                <h2>Search</h2>
            </a>
        </div>

        <div class="block block--mainContentWrapper result-page" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
            <div class="detail_container single_product">
                <div class="user_detail_container">
                    <div class="row_2">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png" style="height: 200px; margin-bottom: 20px;" class="user_img" alt="Avatar">
                    </div>
                    <div class="col_2">
                        <h5><?php echo "$UserName"; ?></h5>
                        <h5>Email:</h5>
                        <p><?php echo "$Email"; ?></p>

                        <?php if ($isNormalUser) {
                            echo "<h5>Books taken: <span>$BooksTaken</span></h5>
                            <h5>Account type: <span>Normal User (not admin)</span></h5>";
                        } else {
                            echo "<h5>Account type: <span>Librarian (admin)</span></h5>";
                        }
                        ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>