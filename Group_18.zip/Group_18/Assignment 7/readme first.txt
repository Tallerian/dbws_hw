To access our website on clamV, please use the following url:
http://clabsql.clamv.jacobs-university.de/~ssah/index.html