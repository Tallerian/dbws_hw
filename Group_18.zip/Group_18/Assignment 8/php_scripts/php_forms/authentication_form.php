<?php include './connection.php'; ?>

<html>

<head>
    <title>Authentication Form</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        function firstCheckBox() {
            console.log("clicked checkbox!");
            $("#normal_user_form").toggle(400);
            if ($("#radioButton").prop("checked")) {
                $("#matriculation_number_input").prop('required', false);
            } else {
                $("#matriculation_number_input").prop('required', true);
            }
            // $("#submit1").toggle(400);
        }

        $(document).ready(function() {
            console.log("ready!");
            $("#matriculation_number_input").prop('required', true);
            $("#faculty_number_input").prop('required', false);
        });


        function firstRadioButton() {
            console.log("clicked 1st radio button");
            $("#student_form").show();
            $("#faculty_member_form").hide();
            $("#matriculation_number_input").prop('required', true);
            $("#faculty_number_input").prop('required', false);
        }

        function secondRadioButton() {
            console.log("clicked 2nd radio button");
            $("#student_form").hide();
            $("#faculty_member_form").show();
            $("#faculty_number_input").prop('required', true);
            $("#matriculation_number_input").prop('required', false);
        }
    </script>
</head>

<body>

    <form method="post">
        <div style="display: flex; flex-direction: column; width: 20%;">
            <label>Email</label>
            <input type="text" name="email" required>
            <label>Password</label>
            <input type="text" name="password" required>
            <label>User Name</label>
            <input type="text" name="userName" required>
            <br>
            <div>
                <label>Are you an admin?</label>
                <input type="checkbox" name="isAdmin" onclick="firstCheckBox()">
            </div>

            <div id="normal_user_form">
                <p>Are you a student or a faculty member?</p>
                <div style="display: flex; flex-direction: row; column-gap: 10px; align-items: center;">
                    <div style="display: flex;">
                        <input type="radio" id="radioButton" checked value="student" name="normal_user_type_radio" onclick="firstRadioButton()">
                        <label for="student">Student</label>
                    </div>
                    <div style="display: flex;">
                        <input type="radio" value="faculty_member" name="normal_user_type_radio" onclick="secondRadioButton()">
                        <label for="faculty_member">Faculty Member</label>
                    </div>
                </div>
                <br>
                <div id="student_form">
                    <label>Matriculation Number</label><br>
                    <input id="matriculation_number_input" type="text" name="matriculation_number"><br><br>
                </div>

                <div style="display: none;" id="faculty_member_form">
                    <label>Faculty Number</label><br>
                    <input id="faculty_number_input" type="text" name="faculty_number"><br><br>
                </div>
            </div>
            <br>
            <input type="submit" id="submit1" name="submit1" style="width: 30%;">
    </form>

    </div>


    <?php

    if (isset($_POST["submit1"])) {
        echo "<h2>Messages (and errors, if they appear): </h2>";
        $email = $_POST["email"];
        $password = $_POST["password"];

        $sql_auth = "INSERT INTO authentication(Email, Password) VALUES('$email', '$password')";

        if (mysqli_query($conn, $sql_auth)) {
            echo ("Record addded successfully!" . "<br>");
        } else {
            echo "Error when inserting " . mysqli_error($conn) . "<br>";
        }

        // -------- User form and query handling below -------------------------------------------

        $userName = $_POST["userName"];
        // $isAdmin = $_POST["isAdmin"] ? $_POST["isAdmin"] : 0;
        $isAdmin = !empty($_POST['isAdmin']) ? $_POST['isAdmin'] : 0;
        echo "isAdmin value: " . $isAdmin . "<br>";
        //below if function converts $isAdmin on/off return from checkbox, into 
        // "1" or "0" $isAdminBool
        $isAdminBool = 0;
        if ($isAdmin == true) {
            echo "isAdmin Bool is true..." . "<br>";
            $isAdminBool = 1;
        }


        // echo "isStudentBool: " . $isStudentBool . "<br>";
        // The following has been implemented so that we can find out the last added AuID 
        // primary key in the authentication table, and make current user's AuID foreign 
        // key take that last added AuID
        $maxAuIDQuery = mysqli_query($conn, "SELECT MAX( `AuID` ) FROM `authentication`");
        // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
        while ($row = $maxAuIDQuery->fetch_assoc()) {
            foreach ($row as $value) {
                if ($value == NULL) {
                    echo "NULL in Auth table";
                    $AuID = 1;
                } else {
                    $AuID = $value;
                    // printf("AuID is NOT NULL: " . $AuID . "\n");
                }
            }
        }
        // insert into user table
        $sql_user = "INSERT INTO user(`UserName`, `IsAdmin`, `AuID`) VALUES ('$userName', $isAdminBool, $AuID)";

        if (mysqli_query($conn, $sql_user)) {
            echo ("Record addded successfully!" . "<br>");
        } else {
            echo "Error when inserting: " . mysqli_error($conn) . "<br>";
        }

        // -------- sql_library and query handling below -------------------------------------------
        if ($isAdminBool == 1) {
            $maxUserIDQuery = mysqli_query($conn, "SELECT MAX( `UserID` ) FROM `user`");
            $UserID;
            // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
            while ($row = $maxUserIDQuery->fetch_assoc()) {
                foreach ($row as $value) {
                    if ($value == NULL) {
                        echo "NULL in User table" . "<br>";
                        $UserID = 1;
                    } else {
                        $UserID = $value;
                        // printf("AuID is NOT NULL: " . $AuID . "\n");
                    }
                }
            }

            echo "I AM A LIBRARIAN" . "<br>";
            $sql_library = "INSERT INTO librarian(`LibrarianID`, `BooksReceived`, `BooksLent`) VALUES ($UserID, 0, 0)";

            if (mysqli_query($conn, $sql_library)) {
                echo ("Record addded successfully!" . "<br>");
            } else {
                echo "Error when inserting: " . mysqli_error($conn) . "<br>";
            }
        } else {
            $maxUserIDQuery = mysqli_query($conn, "SELECT MAX( `UserID` ) FROM `user`");
            $UserID;
            // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
            while ($row = $maxUserIDQuery->fetch_assoc()) {
                foreach ($row as $value) {
                    if ($value == NULL) {
                        echo "NULL in User table" . "<br>";
                        $UserID = 1;
                    } else {
                        $UserID = $value;
                        // printf("AuID is NOT NULL: " . $AuID . "\n");
                    }
                }
            }

            echo "I AM NOT A LIBRARIAN" . "<br>";
            $sql_library = "INSERT INTO normal_user(`NormalUserID`, `BooksTaken`) VALUES ($UserID, 0)";

            if (mysqli_query($conn, $sql_library)) {
                echo ("Record addded successfully!" . "<br>");
            } else {
                echo "Error when inserting: " . mysqli_error($conn) . "<br>";
            }

            $radioVal = $_POST['normal_user_type_radio'] ?? NULL;
            if ($radioVal == "student") {
                echo "You chose the first button" . "<br>";
                $MatriculationID = $_POST['matriculation_number'];
                echo "Matriculation ID: " . $MatriculationID . "<br>";
                $sql_student = "INSERT INTO student(`StudentID`, `matriculation_number`) VALUES ($UserID, $MatriculationID)";
                if (mysqli_query($conn, $sql_student)) {
                    echo ("Record addded successfully!" . "<br>");
                } else {
                    echo "Error when inserting: " . mysqli_error($conn) . "<br>";
                }
            } else if ($radioVal == "faculty_member") {
                echo "You chose the second radio button" . "<br>";
                $FacultyID = $_POST['faculty_number'];
                echo "Faculty ID: " . $FacultyID . "<br>";
                $sql_facultyMember = "INSERT INTO facultymember(`FacultyMemberID`, `faculty_number`) VALUES ($UserID, $FacultyID)";
                if (mysqli_query($conn, $sql_facultyMember)) {
                    echo ("Record addded successfully!" . "<br>");
                } else {
                    echo "Error when inserting: " . mysqli_error($conn) . "<br>";
                }
            }
        }
    }
    ?>

    <br><br>

    <!-- Printing table below: -->

    <div style="display: flex; column-gap: 60px; row-gap: 30px; flex-wrap: wrap;">
        <div id="auth-table">
            <h2>"authentication" table values are</h2>
            <table border="1">
                <tr>
                    <th>AuID</th>
                    <th>Email</th>
                    <th>Password (not encypted)</th>
                </tr>
                <?php
                $conn;
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT * FROM authentication";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["AuID"] . "</td><td>" . $row["Email"] . "</td><td>" . $row["Password"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>

        <div id="user-table">
            <h2>"user" table values are</h2>
            <table border="1">
                <tr>
                    <th>UserID</th>
                    <th>UserName</th>
                    <th>IsAdmin (if true, goes to Librarian)</th>
                    <th>AuID (foreign key)</th>
                </tr>
                <?php
                // $conn;
                // // Check connection
                // if ($conn->connect_error) {
                //     die("Connection failed: " . $conn->connect_error);
                // }
                $sql = "SELECT * FROM user";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["UserID"] . "</td><td>" . $row["UserName"] . "</td><td>" . $row["IsAdmin"] . "</td><td>" . $row["AuID"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>

        <div id="librarian-table">
            <h2>"librarian" table values are</h2>
            <table border="1">
                <tr>
                    <th>LibrarianID</th>
                    <th>BooksReceived</th>
                    <th>BooksLent</th>
                </tr>
                <?php
                // $conn;
                // // Check connection
                // if ($conn->connect_error) {
                //     die("Connection failed: " . $conn->connect_error);
                // }
                $sql = "SELECT * FROM librarian";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["LibrarianID"] . "</td><td>" . $row["BooksReceived"] . "</td><td>" . $row["BooksLent"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>

        <div id="normal-user-table">
            <h2>"normal-user" table values are</h2>
            <table border="1">
                <tr>
                    <th>NormalUserID</th>
                    <th>BooksTaken</th>
                </tr>
                <?php
                $conn;
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT * FROM normal_user";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["NormalUserID"] . "</td><td>" . $row["BooksTaken"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                $testvar = 10;
                ?>
            </table>
        </div>

        <div id="students-table">
            <h2>"student" table values are</h2>
            <table border="1">
                <tr>
                    <th>StudentID</th>
                    <th>Matriculation Number</th>
                </tr>
                <?php
                // $conn;
                // // Check connection
                // if ($conn->connect_error) {
                //     die("Connection failed: " . $conn->connect_error);
                // }
                $sql = "SELECT * FROM student";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["StudentID"] . "</td><td>" . $row["matriculation_number"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>

        <div id="facultymembers-table">
            <h2>"facultymember" table values are</h2>
            <table border="1">
                <tr>
                    <th>FacultyMemberID</th>
                    <th>faculty_number</th>
                </tr>
                <?php
                // $conn;
                // // Check connection
                // if ($conn->connect_error) {
                //     die("Connection failed: " . $conn->connect_error);
                // }
                $sql = "SELECT * FROM facultymember";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["FacultyMemberID"] . "</td><td>" . $row["faculty_number"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>
    </div>


    <br><br><br><a href="../../maintain.php">Go back to maintainence page</a><br> <br>

</body>

</html>