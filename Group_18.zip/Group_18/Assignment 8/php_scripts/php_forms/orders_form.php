<?php include './connection.php'; ?>

<html>

<head>
    <title>Order Entries Form</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            console.log("ready!");
            $("#borrowed_entries_input").prop('required', true);
            $("#returned_entries_input").prop('required', false);
        });


        function firstRadioButton() {
            console.log("clicked 1st radio button");
            $("#borrowed_entries_form").hide();
            $("#returned_entries_form").show();
            $("#returned_entries_input").prop('required', true);
            $("#borrowed_entries_input").prop('required', false);
        }

        function secondRadioButton() {
            console.log("clicked 2nd radio button");
            $("#borrowed_entries_form").show();
            $("#returned_entries_form").hide();
            $("#borrowed_entries_input").prop('required', true);
            $("#returned_entries_input").prop('required', false);
        }
    </script>
</head>

<body>

    <form method="post">
        <div style="display: flex; flex-direction: column; width: 20%;">
            <label>Book ID of the book involved</label>
            <input type="text" name="BookID" required>
            <label>Date the order was placed(yyyy-mm-dd)</label>
            <input type="text" name="DateIssued" required>
            <label>UserID of person borrowing/returning the book</label>
            <input type="text" name="UserID" required>
            <br>
            <!-- </form> -->

            <div id="order_entries_form">
                <p>Are you borrowing or returning a book?</p>
                <div style="display: flex; flex-direction: row; column-gap: 10px; align-items: center;">
                    <div style="display: flex;">
                        <input type="radio" checked value="return" name="order_entries_type_radio" onclick="firstRadioButton()">
                        <label for="return">Return</label>
                    </div>
                    <div style="display: flex;">
                        <input type="radio" value="borrow" name="order_entries_type_radio" onclick="secondRadioButton()">
                        <label for="borrow">Borrow</label>
                    </div>
                </div>
                <br>

                <div id="borrowed_entries_form">
                    <label>Return Deadline</label><br>
                    <input id="borrowed_entries_input" type="text" name="ReturnDeadline"><br><br>
                    <!-- <input type="submit" id="submit2" name="submit"><br><br> -->
                    <!-- </form> -->
                </div>

                <div style="display: none;" id="returned_entries_form">
                    <label>Return Date</label><br>
                    <input id="returned_entries_input" type="text" name="ReturnDate"><br><br>

                </div>
            </div>
            <br>
            <input type="submit" id="submit1" name="submit1" style="width: 30%;">
            <!-- </form> -->
    </form>

    </div>


    <?php

    if (isset($_POST["submit1"])) {
        echo "<h2>Messages (and errors, if they appear): </h2>";
        $BookID = $_POST["BookID"];
        $DateIssued = $_POST["DateIssued"];
        $UserID = $_POST["UserID"];

        $sql_auth = "INSERT INTO order_entry(BookID, UserID, DateIssued) VALUES('$BookID', '$UserID', '$DateIssued')";

        if (mysqli_query($conn, $sql_auth)) {
            echo ("Record addded successfully!" . "<br>");
        } else {
            echo "Error when inserting " . mysqli_error($conn) . "<br>";
        }

        // -------- User form and query handling below -------------------------------------------

        // The following has been implemented so that we can find out the last added AuID 
        // primary key in the authentication table, and make current user's AuID foreign 
        // key take that last added AuID
        $maxOrderIDQuery = mysqli_query($conn, "SELECT MAX( `OrderID` ) FROM `order_entries`");

        while ($row = $maxOrderIDQuery->fetch_assoc()) {
            foreach ($row as $value) {
                if ($value == NULL) {
                    echo "NULL in OrderEntries table";
                    $OrderID = 1;
                } else {
                    $OrderID = $value;
                }
            }
        }

        $radioVal = $_POST['order_entries_type_radio'] ?? NULL;

        // -------- sql_library and query handling below -------------------------------------------
        if ($radioVal == "borrow") {
            echo "You chose the first button" . "<br>";
            echo "Borrowing a book..." . "<br>";
            $ReturnDeadline = $_POST["ReturnDeadline"];
            echo "Return Deadline " . $ReturnDeadlineID . "<br>";

            /* $maxOrderIDQuery = mysqli_query($conn, "SELECT MAX( `OrderID` ) FROM `order_entries`");
                $OrderID;
            
                while ($row = $maxOrderIDQuery->fetch_assoc()) {
                    foreach ($row as $value) {
                        if ($value == NULL) {
                            echo "NULL in order_entries table" . "<br>";
                            $OrderID = 1;
                        } else {
                            $OrderID = $value;
                        }
                    }}*/

            $sql_library = "INSERT INTO borrowed_entries(`BorrowedEntryID`, `ReturnDeadline`) VALUES ($OrderID, $ReturnDeadline)";

            if (mysqli_query($conn, $sql_student)) {
                echo ("Record addded successfully!" . "<br>");
            } else {
                echo "Error when inserting: " . mysqli_error($conn) . "<br>";
            }
        } else if ($radioVal == "return") {
            echo "You chose the second radio button" . "<br>";
            echo "Returning a book..." . "<br>";
            $ReturnDate = $_POST["ReturnDate"];
            echo "ReturnDate: " . $ReturnDate . "<br>";

            /* $maxOrderIDQuery = mysqli_query($conn, "SELECT MAX( `OrderID` ) FROM `order_entries`");
            $OrderID;

            while ($row = $maxOrderIDQuery->fetch_assoc()) {
                foreach ($row as $value) {
                    if ($value == NULL) {
                        echo "NULL in order_entries table" . "<br>";
                        $OrderID = 1;
                    } else {
                        $OrderID = $value;
                    }
                }
            }*/

            $sql_library = "INSERT INTO returned_entries(`ReturnedEntryID`, `ReturnDate`) VALUES ($UserID, $ReturnDate)";

            if (mysqli_query($conn, $sql_library)) {
                echo ("Record addded successfully!" . "<br>");
            } else {
                echo "Error when inserting: " . mysqli_error($conn) . "<br>";
            }
        }
    }
    ?>

    <br><br>

    <!-- Printing table below: -->

    <div style="display: flex; column-gap: 60px; row-gap: 30px; flex-wrap: wrap;">
        <div id="orders-table">
            <h2>"order_entries" table values are</h2>
            <table border="1">
                <tr>
                    <th>OrderID</th>
                    <th>BookID</th>
                    <th>UserID</th>
                    <th>Date Issued</th>
                </tr>
                <?php
                $conn;
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT * FROM order_entry";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["OrderID"] . "</td><td>" . $row["BookID"] . "</td><td>" . $row["UserID"] . "</td><td>" . $row["DateIssued"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>

        <div id="returns-table">
            <h2>"returned_entries" table values are</h2>
            <table border="1">
                <tr>
                    <th>ReturnEntryID</th>
                    <th>Return Date</th>
                </tr>
                <?php
                // $conn;
                // // Check connection
                // if ($conn->connect_error) {
                //     die("Connection failed: " . $conn->connect_error);
                // }
                $sql = "SELECT * FROM returned_entries";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["ReturnedEntryID"] . "</td><td>"  . $row["ReturnDate"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>

        <div id="borrowed-table">
            <h2>"borrowed_entries" table values are</h2>
            <table border="1">
                <tr>
                    <th>BorrowedEntryID</th>
                    <th>ReturnDeadline</th>
                </tr>
                <?php
                // $conn;
                // // Check connection
                // if ($conn->connect_error) {
                //     die("Connection failed: " . $conn->connect_error);
                // }
                $sql = "SELECT * FROM borrowed_entries";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["BorrowedEntryID"] . "</td><td>" . $row["ReturnDeadline"] . "</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }
                // $conn->close();
                ?>
            </table>
        </div>
    </div>


    <br><br><br><a href="../../maintain.php">Go back to maintainence page</a><br> <br>

</body>

</html>