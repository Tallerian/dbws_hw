<?php
// Include config file
require_once "connection.php";

// Define variables and initialize with empty values
$email = $username = $password = $confirm_password = $matric_num = $faculty_num = "";
$email_err = $username_err = $password_err = $confirm_password_err = $matric_num_err = $faculty_num_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } elseif (!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        // Prepare a select statement
        $sql = "SELECT AuID FROM authentication WHERE Email = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email);

            // Set parameters
            $param_email = trim($_POST["email"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $email_err = "This email is already taken.";
                } else {
                    $email = trim($_POST["email"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))) {
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else {
        // Prepare a select statement
        $sql = "SELECT UserID FROM user WHERE UserName = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Set parameters
            $param_username = trim($_POST["username"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $username_err = "This username is already taken.";
                } else {
                    $username = trim($_POST["username"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have atleast 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Obtain isAdmin bool
    $isAdmin = !empty($_POST['isAdmin']) ? $_POST['isAdmin'] : 0;
    echo "isAdmin value: " . $isAdmin . "<br>";
    //below if function converts $isAdmin on/off return from checkbox, into 
    // "1" or "0" $isAdminBool
    $isAdminBool = 0;
    if ($isAdmin == true) {
        echo "isAdmin Bool is true..." . "<br>";
        $isAdminBool = 1;
    }

    // Validate matriculation number
    if (!$isAdminBool && empty(trim($_POST["matric_num"])) && empty(trim($_POST["faculty_num"]))) {
        $matric_num_err = "Please enter a matriculation number.";
    } elseif (!$isAdminBool && !is_numeric(trim($_POST["matric_num"])) && !is_numeric($_POST["faculty_num"])) {
        $matric_num_err = "Matriculation number can contain only numbers.";
    } else {
        // Prepare a select statement
        $sql = "SELECT StudentID FROM student WHERE matriculation_number = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_matric_num);

            // Set parameters
            $param_matric_num = trim($_POST["matric_num"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $matric_num_err = "This matriculation number already exists.";
                } else {
                    $matric_num = trim($_POST["matric_num"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Validate faculty number
    if (!$isAdminBool && empty(trim($_POST["faculty_num"])) && empty(trim($_POST["matric_num"]))) {
        $faculty_num_err = "Please enter a faculty number.";
    } elseif (!$isAdminBool && !is_numeric(trim($_POST["faculty_num"])) && !is_numeric($_POST["matric_num"])) {
        $faculty_num_err = "Faculty number can only contain numbers.";
    } else {
        // Prepare a select statement
        $sql = "SELECT FacultyMemberID FROM facultymember WHERE faculty_number = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_faculty_num);

            // Set parameters
            $param_faculty_num = trim($_POST["faculty_num"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $faculty_num_err = "This faculty number already exists.";
                } else {
                    $faculty_num = trim($_POST["faculty_num"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Check input errors before inserting in database
    if (empty($email_err) && empty($username_err) && empty($password_err) && empty($confirm_password_err)) {
        // echo "<h1>Before prepare:</h1>";
        // Prepare an insert statement
        $sql = "INSERT INTO authentication (email, password) VALUES (?, ?)";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_email, $param_password);

            // Set parameters
            $param_username = $email;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash

            // echo "<h1>before execute stmt:</h1>";
            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                echo "<h1>inside execute stmt:</h1>";

                // The following has been implemented so that we can find out the last added AuID 
                // primary key in the authentication table, and make current user's AuID foreign 
                // key take that last added AuID
                $maxAuIDQuery = mysqli_query($conn, "SELECT MAX( `AuID` ) FROM `authentication`");
                // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
                while ($row = $maxAuIDQuery->fetch_assoc()) {
                    foreach ($row as $value) {
                        if ($value == NULL) {
                            echo "NULL in Auth table";
                            $AuID = 1;
                        } else {
                            $AuID = $value;
                            // printf("AuID is NOT NULL: " . $AuID . "\n");
                        }
                    }
                }
                // Insert into user table
                $sql_user = "INSERT INTO user(`UserName`, `IsAdmin`, `AuID`) VALUES ('$username', $isAdminBool, $AuID)";
                // $sql_user = "INSERT INTO user(`UserName`, `IsAdmin`, `AuID`) VALUES ('$username', 0, $AuID)";
                if (mysqli_query($conn, $sql_user)) {
                    echo ("Record addded successfully!" . "<br>");
                } else {
                    echo "Error when inserting: " . mysqli_error($conn) . "<br>";
                }

                // inserting into either normal_user/librarian depending on isAdmin,
                // and then inserting into student/faculty_member depending on radio button value
                if ($isAdminBool == 1) {
                    $maxUserIDQuery = mysqli_query($conn, "SELECT MAX( `UserID` ) FROM `user`");
                    $UserID;
                    // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
                    while ($row = $maxUserIDQuery->fetch_assoc()) {
                        foreach ($row as $value) {
                            if ($value == NULL) {
                                echo "NULL in User table" . "<br>";
                                $UserID = 1;
                            } else {
                                $UserID = $value;
                                // printf("AuID is NOT NULL: " . $AuID . "\n");
                            }
                        }
                    }

                    echo "I AM A LIBRARIAN" . "<br>";
                    $sql_library = "INSERT INTO librarian(`LibrarianID`, `BooksReceived`, `BooksLent`) VALUES ($UserID, 0, 0)";

                    if (mysqli_query($conn, $sql_library)) {
                        echo ("Record addded successfully!" . "<br>");
                    } else {
                        echo "Error when inserting: " . mysqli_error($conn) . "<br>";
                    }
                } else {
                    $maxUserIDQuery = mysqli_query($conn, "SELECT MAX( `UserID` ) FROM `user`");
                    $UserID;
                    // printf("Select returned %d rows.\n", mysqli_num_rows($maxAuIDQuery));
                    while ($row = $maxUserIDQuery->fetch_assoc()) {
                        foreach ($row as $value) {
                            if ($value == NULL) {
                                echo "NULL in User table" . "<br>";
                                $UserID = 1;
                            } else {
                                $UserID = $value;
                                // printf("AuID is NOT NULL: " . $AuID . "\n");
                            }
                        }
                    }

                    echo "I AM NOT A LIBRARIAN" . "<br>";
                    $sql_library = "INSERT INTO normal_user(`NormalUserID`, `BooksTaken`) VALUES ($UserID, 0)";

                    if (mysqli_query($conn, $sql_library)) {
                        echo ("Record addded successfully!" . "<br>");
                    } else {
                        echo "Error when inserting: " . mysqli_error($conn) . "<br>";
                    }

                    $radioVal = $_POST['normal_user_type_radio'] ?? NULL;
                    if ($radioVal == "student") {
                        echo "You chose the first button" . "<br>";
                        // $MatriculationID = $_POST['matric_num'];
                        echo "Matriculation ID: " . $matric_num . "<br>";
                        $sql_student = "INSERT INTO student(`StudentID`, `matriculation_number`) VALUES ($UserID, $matric_num)";
                        if (mysqli_query($conn, $sql_student)) {
                            echo ("Record addded successfully!" . "<br>");
                        } else {
                            echo "Error when inserting into student: " . mysqli_error($conn) . "<br>";
                        }
                    } else if ($radioVal == "faculty_member") {
                        echo "You chose the second radio button" . "<br>";
                        // $FacultyID = $_POST['faculty_number'];
                        echo "Faculty ID: " . $faculty_num . "<br>";
                        // $sql_facultyMember = "INSERT INTO facultymember(`FacultyMemberID`, `faculty_number`) VALUES ($UserID, $faculty_num)";
                        $sql_facultyMember = "INSERT INTO facultymember(`FacultyMemberID`, `faculty_number`) VALUES ($UserID, $faculty_num)";
                        if (mysqli_query($conn, $sql_facultyMember)) {
                            echo ("Record addded successfully!" . "<br>");
                        } else {
                            echo "Error when inserting into faculty member: " . mysqli_error($conn) . "<br>";
                        }
                    }
                }

                echo "<h1>Everything went fine, Sign Up successful!</h1>";
                // Redirect to login page
                // header("location: login_form.php");
            } else {
                printf ("Error: %s\n", mysqli_stmt_error($stmt));
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font: 14px sans-serif;
        }

        .wrapper {
            width: 360px;
            padding: 20px;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        function firstCheckBox() {
            console.log("clicked checkbox!");
            $("#normal_user_form").toggle(400);
            if ($("#radioButton").prop("checked")) {
                $("#matriculation_number_input").prop('required', false);
            } else {
                $("#matriculation_number_input").prop('required', true);
            }
        }

        $(document).ready(function() {
            console.log("ready!");
            $('input:not(.button)').val('');
            $("#matriculation_number_input").prop('required', true);
            $("#faculty_number_input").prop('required', false);
        });

        // $(window).load(function() {
        //     console.log("Window Load!");
        //     $('myForm').children('input:not(#submit)').val('');
        // });


        function firstRadioButton() {
            console.log("clicked 1st radio button");
            $("#student_form").show();
            $("#faculty_member_form").hide();
            $("#matriculation_number_input").prop('required', true);
            $("#faculty_number_input").prop('required', false);
        }

        function secondRadioButton() {
            console.log("clicked 2nd radio button");
            $("#student_form").hide();
            $("#faculty_member_form").show();
            $("#faculty_number_input").prop('required', true);
            $("#matriculation_number_input").prop('required', false);
        }
    </script>
</head>

<body>
    <div class="wrapper">
        <h2>Sign Up</h2>
        <p>Please fill this form to create an account.</p>
        <form id="myForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Are you an admin?</label>
                <input type="checkbox" class="button" name="isAdmin" onclick="firstCheckBox()">
            </div>
            <div id="normal_user_form" class="form-group">
                <label>Are you a student or a faculty member?</label>
                <div>
                    <input type="radio" class="button" checked id="radioButton" value="student" name="normal_user_type_radio" onclick="firstRadioButton()">
                    <label for="student">Student</label>
                    <input type="radio" class="button" value="faculty_member" name="normal_user_type_radio" onclick="secondRadioButton()">
                    <label for="faculty_member">Faculty Member</label>
                </div>
                <div id="student_form" class="form-group">
                    <label>Matriculation Number</label>
                    <input id="matriculation_number_input" type="text" name="matric_num" class="form-control <?php echo (!empty($matric_num_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $matric_num; ?>">
                    <span class="invalid-feedback"><?php echo $matric_num_err; ?></span>
                </div>

                <div style="display: none;" id="faculty_member_form" class="form-group">
                    <label>Faculty Number</label>
                    <input id="faculty_number_input" type="text" name="faculty_num" class="form-control <?php echo (!empty($faculty_num_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $faculty_num; ?>">
                    <span class="invalid-feedback"><?php echo $faculty_num_err; ?></span>
                </div>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary button" value="Submit">
                <input type="reset" class="btn btn-secondary ml-2 button" value="Reset">
            </div>
            <p>Already have an account? <a href="login_form.php">Login here</a>.</p>
        </form>
    </div>
</body>

</html>