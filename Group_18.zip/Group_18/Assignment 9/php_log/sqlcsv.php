<?php
   // Include config file
   require_once "connection.php";

   $pdo= new PDO("mysql:host=$serverName; dbname=$dbName",$userName , $password,[PDO::ATTR_ERRMODE=> PDO::ERRMODE_EXCEPTION]);

  //CREATE EMPTY CSV FILE
  $fh= fopen("export.csv", "a");
  if( $fh==false ){ exit ("Failed to create CSV file");}
//adding new line
    
   //Get Users + Direct Output
   $stmt= $pdo->prepare("SELECT * FROM authentication WHERE AuID=8");
   $stmt->execute();
   while($row =$stmt->fetch(PDO::FETCH_NAMED)){
       //row data (CSV columns are separated with comma)
     fputcsv($fh, [$row['AuID'], $row['Email'], $row['Password']]);
   }
   fclose($fh);
   echo "Done!";
?>