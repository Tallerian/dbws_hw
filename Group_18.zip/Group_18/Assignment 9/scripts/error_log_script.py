import re
import os
import csv
import time


# Fri Nov 12

def format_date(raw_date):
    # print(raw_date)
    date_conversion_dict={"Jan":"01","Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06", "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12"}
    new_date = raw_date[8:10] +"."  + date_conversion_dict[raw_date[4:7]]+ "."+ "2021"
    print(new_date)  
    return new_date     
   

def main():
    
    
    error_log_filename ="error_log.txt"
    try:
        username = input("Enter your clamv user name to be used to login to get access log: ")
        command_str = "scp "+username+"@10.72.1.14:/var/log/apache2/error_log ."
        os.system(command_str)
        error_log_filename = "error_log"
    except:
        print("Errror while sshing into clamv .")
        print("Error while fetching data")
        # print("Accessing the file, error_log.txt, as default")
        time.sleep(2)
        exit()
    
    
    reading_file_pointer = open(error_log_filename, 'r')
    csv_file_pointer = open('error_result.csv', 'w')
    writer = csv.writer(csv_file_pointer)
    header = ['IP', 'Time', 'Date', 'Error']
    writer.writerow(header)
    
    
    count = 0
    
    count_my_visit = 0
    while True:
        count += 1
        line = reading_file_pointer.readline()
        if not line:
            break
        
        if '~ssah' in line :
            csv_row =[]
            count_my_visit += 1
            
            # IP
            # print("IP")
            # print(re.findall(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', line)[0])
            csv_row.append(re.findall(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', line)[0])
            
            # Time
            # print("time")
            # print(re.findall(r'\d{2}\:\d{2}\:\d{2}', line)[0])
            csv_row.append(re.findall(r'\d{2}\:\d{2}\:\d{2}', line)[0])
            
            
            #date
            # print("date")
            # print(re.search('\[(.*?)\]', line).group(1)[0:10])
            # csv_row.append(re.findall('\[(.*?)\]', line)[0])
            formatted_date = format_date(re.search('\[(.*?)\]', line).group(1)[0:10])
            csv_row.append(formatted_date)


                        
            # ERROR
            # print("ERROR")
            # print(line.split(" PHP ",1)[1])
            csv_row.append(line.split(" PHP ",1)[1])
            

            # print(csv_row)
            # print("======================================================================================")
            writer.writerow(csv_row)
                
    
    reading_file_pointer.close()
    csv_file_pointer.close()
    print("the number of line for my visit is ", count_my_visit)

if __name__ == "__main__":
    main()
