# Group_18

Members:

Denisa	Checiu	DenisaCG	d.checiu@jacobs-university.de <br/>
Sandip	Sah	SandipkSah	s.sah@jacobs-university.de <br/>
Ainna	Zafar	ainna-zafar	a.zafar@jacobs-university.de  <br/>
Muhammad Umar	Shakeel	umar-00	m.shakeel@jacobs-university.de <br/>
