<?php

$long_id = filter_input(INPUT_POST, "long_id", FILTER_VALIDATE_INT);
$train_name = $_POST["train_name"];
$route_id = filter_input(INPUT_POST, "route_id", FILTER_VALIDATE_INT);
$price = filter_input(INPUT_POST, "price", FILTER_VALIDATE_INT);


$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbws";

$connect = mysqli_connect($host, $user, $pass, $dbname);

if(mysqli_connect_errno()){
    die("connection error");
}

if(empty($long_id) || empty($route_id) || empty($train_name) || empty($price)){

  $check1="SELECT train_name FROM train WHERE train_name = '$train_name'";
  $check2="SELECT route_id FROM route WHERE route_id = '$route_id'";
  $check3="SELECT long_id FROM long_dist WHERE long_id = '$long_id'";

  if(!$check3){
    echo"This long_id is no where to be found";
    include ("inlong.html");
    exit();
  }

  if($check1){
    echo"This $train_name already exists in the database";
    include ("inlong.html");
    exit();
  }

  if(!$check2){
    echo"This route_id is no where to be found";
    include ("inlong.html");
    exit();
  }

  echo"Please Enter valid data";
  include ("inlong.html");
  exit();
}

else{
  include("bar.html");
  $sql = "INSERT INTO long_Dist VALUES (?, ?, ?, ?)";

  $stmt = mysqli_stmt_init($connect);

  if(!mysqli_stmt_prepare($stmt, $sql)){
    die(mysqli_error($connect));
  }

  mysqli_stmt_bind_param($stmt, "isii", $long_id, $train_name, $route_id, $price);

  mysqli_stmt_execute($stmt);

  echo "Hello it was successful";
}



?>