
<!DOCTYPE html>
<html>
<head>

    <link rel="stylesheet" href="css/uni.css">
    <title>Search Results</title>

</head>

<body>

    <header>
        <div class="inner-width">
          <a href="index.html"><img src="img/logo.png" alt="#"></a>
          <i class="menu-toggle-btn fas fa-bars"></i>
          <nav class="navigation-menu">
            <a href="#"><i class="fas fa-home home"></i> Home</a>
            <a href="#"></i> Explore</a>
            <a href="#"></i> Contact Us</a>
          </nav>
        </div>
      </header>
</body>
</html>

<?php

$name = $_POST["p_name"];
$dep = $_POST["dep"];
$arr = $_POST["arr"];

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbws";

$connect = mysqli_connect($host, $user, $pass, $dbname);

if(mysqli_connect_errno()){
    die("connection error");
}

$sql = "SELECT train_name, p_name FROM train, passenger, route_path, route
WHERE '$dep' = route_path.s_name AND route_path.route_id = route.route_id AND route.train_id = train.train_id
UNION
SELECT train_name, p_name FROM train, passenger, route_path, route
WHERE '$arr' = route_path.s_name AND route_path.route_id = route.route_id AND route.train_id = train.train_id;";

$result = $connect-> query($sql);

echo"<div id='registration-form'>";
echo"<div class='fieldset'>";
echo"<legend>Train information!</legend>";
echo"<form>";

if($result->num_rows > 0){
    //output data of each row

    
    while($row = $result->fetch_assoc()) {
        echo"<div class='row'>";
        echo "<p> Train ". $row["train_name"];
        echo "</div>";
    }
}else{
    echo "0 results";
}

echo"</form>";
echo"</div>";
echo"</div>";

$connect->close();

?>