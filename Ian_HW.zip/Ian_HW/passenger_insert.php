

<?php

$name = $_POST["p_name"];
$dep = $_POST["dep"];
$arr = $_POST["arr"];

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbws";

$connect = mysqli_connect($host, $user, $pass, $dbname);

if(mysqli_connect_errno()){
    die("connection error");
}

if(empty($name) || $dep == $arr){
  echo"Please Enter valid data";
  include ("passenger.html");
  exit();
}

else{
  include("bar.html");
  $sql = "INSERT INTO passenger (p_name, departure, destination) VALUES (?,?,?);";

  $stmt = mysqli_stmt_init($connect);

  if(!mysqli_stmt_prepare($stmt, $sql)){
    die(mysqli_error($connect));
  }

  mysqli_stmt_bind_param($stmt, "sss", $name, $dep, $arr);

  mysqli_stmt_execute($stmt);

  echo "Hello it was successful";
}



?>