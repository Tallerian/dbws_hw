
<!DOCTYPE html>
<html>
<head>

    <link rel="stylesheet" href="css/uni.css">
    <title>Search Results</title>

</head>

<body>

    <header>
        <div class="inner-width">
          <a href="index.html"><img src="img/logo.png" alt="#"></a>
          <i class="menu-toggle-btn fas fa-bars"></i>
          <nav class="navigation-menu">
            <a href="#"><i class="fas fa-home home"></i> Home</a>
            <a href="#"></i> Explore</a>
            <a href="#"></i> Contact Us</a>
          </nav>
        </div>
      </header>
</body>
</html>

<?php
$s_name = $_POST["s_name"];

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbws";

$connect = mysqli_connect($host, $user, $pass, $dbname);

if(mysqli_connect_errno()){
    die("connection error");
}

$sql = "SELECT train_name
FROM train, route_path, route
WHERE train.train_id = route.train_id AND route_path.route_id = route.route_id AND s_name = '$s_name';";

$result = $connect-> query($sql);

if($result->num_rows > 0){
    //output data of each row

    echo"<div id='registration-form'>";
    echo"<div class='fieldset'>";
    echo"<legend>Train information!</legend>";
    echo"<form>";
    while($row = $result->fetch_assoc()) {
        echo"<div class='row'>";
        echo "<p> Train ". $row["train_name"];
        echo "</div>";
    }
    echo"</form>";
    echo"</div>";
    echo"</div>";
}else{
    echo "0 results";
}

$connect->close();

?>