<?php 
if(!session_status()){
    session_start();
}

echo"<p>Obtaining Usernames .......</p>";
if(isset($_POST['admin']) ){
    if($_POST['admin'] == "Login"){
        echo"<p>Obtaining Usernames .......</p>";
        $username = $_POST["username"];
        $password = $_POST["password"];


        $sql = "SELECT User, Password FROM mysql.user;";
        $result = $connect-> query($sql);


        $check1 = $connect-> query($sql);
        if($check1->num_rows > 0){
            echo"<p>checking if success</p>";
            while($row = $result->fetch_assoc()) {
                if($username == $row["User"] && $password == "SupplyFill"){
                    $_SESSION['user'] = $username;
                    $_SESSION['pass'] = $password;
                    session_destroy();
                    session_start();
                    $_SESSION['access'] = 1;
                    echo"<p>yeeee it was success</p>";
                }
            }
        }
    
    }else{
        $_SESSION['access'] = 0;
    }


    //Here we check if the Value is LOGOUT
    if($_POST['admin'] == "Logout"){
        $_SESSION['user'] = "group16";
        $_SESSION['pass'] = "ourreveal";
        echo"<p>Not a success</p>";
        session_destroy();
        session_start();
        $_SESSION['access'] = 0;
    }
    $da = $_SESSION['access'];
    echo"<p>a success $da</p>";
    include("./index.php");
    //header("Location:./index.php");
}
else{
    //header("Location:./index.php");
}





?>