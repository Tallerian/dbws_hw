<?php 

    if (!session_status()){
        session_start();
    }
    

    $host = "localhost";
    $_SESSION['user'] = "group16";
    $_SESSION['pass'] = "ourreveal";
    $dbname = "group16";

    $connect = @mysqli_connect($host, $_SESSION['user'], $_SESSION['pass'], $dbname);
    
    if(mysqli_connect_errno()){
        die("connection error");
    }
?>