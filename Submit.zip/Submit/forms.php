<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 

<style> 
  body {
    background-image: url('./img/hpbanner.png');
    background-repeat: no-repeat ; 
    background-size: cover; 
  }
</style>

<body>
    <title> Quick Rail | Forms Page </title> 
        <h1 id="form-head"> Input Forms </h1> 
        <div class="something left" > 
            <a href="./forms/station_form.php">Station</a> 
            <a href="./forms/train.php">Train</a> 
            <a href="./forms/passenger.php">Passenger</a> 
            <a href="./forms/adult.php">Adult</a> 
        </div> 
        <div class="something main" > 
            <a href="./forms/longdist.php">Long Distance</a> 
            <a href="./forms/schedule_form.php">Schedule</a> 
            <a href="./forms/regional_form.php">Regional</a>
            <a href="./forms/trainsearch.php">Train Search</a>  
        </div> 
        <div class="something right" > 
            <a href="./forms/route_form.php">Route</a> 
            <a href="./forms/routepath_form.php">Route Path</a> 
            <a href="./forms/student.php">Student</a> 
            <a href="./forms/passenger_finder.php">Passenger Search</a> 
        </div> 
        <div class="something right" > 
        <a href="./forms/Station-Train.php">Station-Train Search</a> 
        </div>

</body> 
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
<?php 
    include('./footer.php'); 
?>