<?php
    include('../header.php');
    echo '<h3>"Error: " . $sql . "<br>" . mysqli_error($conn)</h3>';
    include('./footer.php');
?>