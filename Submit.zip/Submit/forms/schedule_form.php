<!DOCTYPE html>
<?php
require '../header.php';
?>
<html>
<style> 
      body {
        background-image: url('../img/Background_1.jpg');
        background-repeat: no-repeat ; 
        background-size: cover;
      }
    </style>
<head>
    <div id="registration-form">
        <div class='fieldset'>
          <legend>Schedule</legend>
          <form action="schedule_insert.php" method="post" >
            
            <div class='row'>
              <label for='firstname'>Existing Train ID</label>
              <input type="text" placeholder="Train ID" name= "trainID" >
            </div>

            <div class='row'>
              <label for="studentid">Departure time:</label>
              <input type="time" id="start" name="dep" required>
            </div>

            <div class='row'>
                <label for="studentid">Arrival time:</label>
                <input type="time" id="end" name="arr" required>
            </div>
            
            <input type="submit" value="Register">
          </form>
        </div>
      </div>

      <?php include '../footer.php' ?>
</body>

</html>