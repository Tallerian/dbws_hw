<?php 
    include '../header.php'; 
    include '../connect.php' ;
    if(isset($_POST['create'])){
      $count = 0;
      if(!$_POST['p_id']){
        $error.= "<br/>please Enter Passenger ID";	
      }
      if(!$_POST['s_id']){
        $error.= "<br/>please Enter Student ID";	
      } 
      if ($_POST['p_id']){
        $p_id = $_POST['p_id']; 
        $query = "SELECT * FROM passenger WHERE p_id = '$p_id' ";
        $result = mysqli_query($connect, $query); 
        $count = mysqli_num_rows($result);
        if($count == 0){
          $error.= "<br/> Passenger ID doesn't exist.";	
        }
      }   
      if ($_POST['s_id']){
        $s_id = $_POST['s_id']; 
        $query = "SELECT * FROM student WHERE student_id = '$s_id' ";
        $result = mysqli_query($connect, $query); 
        $count = mysqli_num_rows($result);
        if($count > 0){
          $error.= "<br/> Student ID doesn't exist. ";	
        }
      }    

      if (isset($error)) {
        echo "There Were error(s) In Your Signup Details :" .$error;	
      } 
      else{
        $p_id = $_POST['p_id']; 
        $s_id = $_POST['s_id']; 
        $query = "INSERT INTO student VALUES('$p_id', '$s_id')";
        if (mysqli_query($connect, $query)) {
          header("Location: ./success.php") ; 
        }
        else {
          header("Location: ./failure.php") ; 
        }
      }
    }   
?>

<!DOCTYPE html> 
<html> 
    <style> 
      body {
        background-image: url('../img/Background_1.jpg');
        background-repeat: no-repeat ; 
        background-size: cover;
      }
    </style>

    <title> Quick Rail | Student Form </title> 

    <div id="registration-form">
        <div class='fieldset'>
          <legend>Student Form!</legend>
          <form action="student.php" method="POST" >
            <div class='row'>
              <label for='Passenger'>Passenger ID </label> <br>
              <input type="number" placeholder="Passenger ID" id='passengerID' data-required="true" name="p_id">
            </div>
            <div class='row'>
              <label for='Student ID'>Student ID </label> <br>
              <input type="number" placeholder="Student ID" id='studentID' data-required="true" name="s_id">
            </div>
            
            <input type="submit" value="Input Data" name="create">
          </form>
        </div>
    </div>
    <br><br><br><br><br><br><br><br><br>
    <div>
  </div>


<?php 
    include('../footer.php'); 
?>