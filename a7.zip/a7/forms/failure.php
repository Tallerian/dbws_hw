<?php
    include('./header.php');
    echo "<h3> Data insertion was unsuccessful</h3>"
    include('../footer.php')
?>