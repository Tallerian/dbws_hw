<?php
    include("./header.php");

    if(isset($_POST['search'])){
        require_once ('../connect.php');

        $search = filter_input(INPUT_POST, 'search');

        $query = "SELECT * FROM passenger 
        WHERE  p_name LIKE '%search' ";

        $stm = $conn->prepare($query);
        $stm->execute();
        $results = $stm->fetchAll();
        $stm->closeCursor();

        $result = mysqli_query($conn, $query);
        $clean_data = mysqli_fetch_assoc($result);
        mysqli_free_result($result);

        $queryResult = mysqli_num_rows($results);
    }
?>


<!DOCTYPE html>
<html> 
    <style> 
      body {
        background-image: url('../img/Background_1.jpg');
        background-repeat: no-repeat ; 
        background-size: cover;
      }
    </style>

    <title> Quick Rail | Passenger Search Form </title> 
    <div id="registration-form">
        <div class='fieldset'>
            <legend>Passenger Search Form!</legend>
            <form action="passenger.php" method="post" > 
                <table>
                    <tr>
                        <th>Passenger ID</th>
                        <th>Passenger Name</th>
                    </tr>
                </table>
                <?php foreach ($results as $result) : ?>
                    <table>
                        <tr>
                            <td><?php echo $result['p_id'] ?></td>
                            <td><?php echo $result['p_name'] ?></td>
                        </tr>
                    </table>
                <?php endforeach ?>
            </form>
        </div>
    </div>
    
</body>
</html>

<?php include '../footer.php' ?>


