<?php

$s_name = $_POST["s_name"];
$station_id = filter_input(INPUT_POST, "station_id", FILTER_VALIDATE_INT);

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbws";

$connect = mysqli_connect($host, $user, $pass, $dbname);

if(mysqli_connect_errno()){
    die("connection error");
}

$sql = "INSERT INTO station (station_id, s_name)
        VALUES (?,?)";

$stmt = mysqli_stmt_init($connect);

if(!mysqli_stmt_prepare($stmt, $sql)){
    die(mysqli_error($connect));
}

mysqli_stmt_bind_param($stmt, "is", $station_id, $s_name);

mysqli_stmt_execute($stmt);

echo "Hello it was successful";

?>