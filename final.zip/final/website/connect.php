<?php 
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "group16";
    
    $connect = mysqli_connect($host, $user, $pass, $dbname);
    
    if(mysqli_connect_errno()){
        die("connection error");
    }
?>