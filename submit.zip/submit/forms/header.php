<html lang="en">
  <?php
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
  error_reporting(E_ALL);
  ?>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../styles/styles.css">
  </head>
  <body>
    <header>
      <div class="brand"><a href="../index.php">Quick Rail</a></div>
      <nav>
        <ul>
          <li><a href="../index.php">Home</a></li>
          <li><a href="../explore.php">Explore</a></li>
          <li><a href="../contact.php">Contact</a></li>
          <li class="form_link"><a href="../forms.php">Forms</a></li>
        </ul>
      </nav>
      <div class="icon" onclick="toggleMobileMenu(this)">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <ul class="mobile-menu">
          <li><a href="../index.php">Home</a></li>
          <li><a href="../explore.php">Explore</a></li>
          <li><a href="../contact.php">Contact</a></li>
          <li class="form_link"><a href="../forms.php">Forms</a></li>
        </ul>
      </div>
    </header>
    <script src="index.js"></script>

