<?php 
    //connecting to the database
    $conn = mysqli_connect("localhost", "group16", "1234", "group16"); 
    //servername, db_user, db_pass, db_name

    if(!$conn)
        echo 'Connection Error: ' . mysqli_connect_error(); 
?>

