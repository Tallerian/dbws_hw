<?php 
    $host = "localhost";
    $user = "group16";
    $pass = "ourreveal";
    $dbname = "group16";
    
    $connect = mysqli_connect($host, $user, $pass, $dbname);
    
    if(mysqli_connect_errno()){
        die("connection error");
    }
?>