<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 

<html> 
    <title> Quick Rail | Contact Page </title> 


<?php 
    include('./footer.php'); 
?>