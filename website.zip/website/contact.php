<?php 
    include './header.php' ; 
    include './connect/php' ;
    if(isset($_POST['submit'])){
        header("Location: ./contact.php"); 
        echo "<p> ckeoirvneoirvb </p> ";
    }
?>

<!DOCTYPE html> 

<div class="container">
  <form action="action_page.php">

    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Country</label>
    <select id="country" name="country">
      <option value="australia">Australia</option>
      <option value="canada">Canada</option>
      <option value="usa">USA</option>
      <option value="usa">Germany</option>
      <option value="usa">Rwanda</option>
      <option value="usa">Tanzania</option>
    </select>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <button type="button"> Submit </button> 

  </form>
</div>
<?php 
    include('./footer.php'); 
?>