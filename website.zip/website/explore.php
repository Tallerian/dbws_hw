<?php include 'header.php' ?> 

<link rel="stylesheet" href="./styles/styleexplore.css">
    <script src="index.js"></script>
    <title> Quick Rail | Explore Page </title> 

  <div id="wrap">
    <div id="contentwrap">
      <div id="mainpage">
        <div id="threecolumns">
          <div class="col1">
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">RS1 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Verden-Aller -> Bremen Vegesack</p>
                    <ul>
                      <li>Verden Aller</li>
                      <li>Bremen HBF</li>
                      <li>Bremen Burg</li>
                      <li>Bremen Schonebeck</li>
                      <li>Bremen Vegesack</li>
                    </ul>
                    <p class="stops">Regional Train</p>
                  </div>
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">RS2 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Twistringen -> Bremen-HBF</p>
                    <ul>
                      <li>Twistringen</li>
                      <li>Bassum</li>
                      <li>Bramstedt</li>
                      <li>Skye</li>
                      <li>Barrien</li>
                    </ul>
                    <p class="stops">Regional Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">RE1 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Hannover-HBF -> Bremen-HBF</p>
                    <ul>
                      <li>Hannover-HBF</li>
                      <li>Wunstorf</li>
                      <li>Neustadty am Ruebenberg</li>
                      <li>Nienburg</li>
                      <li>Eystrup</li>
                    </ul>
                    <p>Regional Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
          </div>
          <div class="col2">
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#"></a>RE8 Train</h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Hannover->Bremerhaven-Lehe</p>
                    <ul>
                      <li>Hannover-HBF</li>
                      <li>Wunstorf</li>
                      <li>Neustadty am Ruebenberg</li>
                      <li>Nienburg</li>
                      <li>Eystrup</li>
                    </ul>
                    <p>Regional Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">RE4 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Hamburg-HBF -> Bremen-HBF</p>
                    <ul>
                      <li>Hamburg-HBF</li>
                      <li>Hamburg-Harburg</li>
                      <li>Buchholz</li>
                      <li>Tostedt</li>
                      <li>Rotenburg</li>
                    </ul>
                    <p class="stops">Regional Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">ICE1139 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Bremen-HBF -> Munich-HBF</p>
                    <ul>
                      <li>Hannover-HBF</li>
                      <li>Goettigen</li>
                      <li>Kassel-Wilhelmshoehe</li>
                      <li>Fulda</li>
                      <li>Wuerzburg-HBF</li>
                    </ul>
                    <p>InterCity Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
          </div>
          <div class="col3">
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">IC2314 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Koln-HBF -> Husum</p>
                    <ul>
                      <li>Dusseldorf</li>
                      <li>Essen</li>
                      <li>Bochum</li>
                      <li>Dortmund-HBF</li>
                      <li>Itzehoe</li>
                    </ul>
                    <p>InterCity Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">ICE1025 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <p>Hamburg-Altona -> Frankfurt-HBF</p>
                    <ul>
                      <li>Hamburg Damtor</li>
                      <li>Hamburg-HBF</li>
                      <li>Koln-HBF</li>
                      <li>Frankfurt Flughafen</li>
                      <li>Frankfurt-HBF</li>
                    </ul>
                    <p>InterCity Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
            <div class="ftbox">
              <div class="ftbox1"></div>
              <div class="ftcontent">
                <div class="post">
                  <h2><a href="#">IC1933 Train</a></h2>
                  <img src="img/RS1map.png" width="270" height="140" alt="" class="hboxthumb" />
                  <div class="stops">
                    <ul>
                      <p>Oldenburg -> Leipzig</p>
                      <li>Delmenhorst</li>
                      <li>Bremen-HBF</li>
                      <li>Hannover-HBF</li>
                      <li>Bitterfeld</li>
                      <li>Leipzig-HBF</li>
                    </ul>
                    <p>InterCity Train</p>
                  </div> 
                </div>
              </div>
              <div class="ftbox2"></div>
            </div>
          </div>
        <div class="clear"></div>
      </div>


<?php 
    include('./footer.php'); 
?>