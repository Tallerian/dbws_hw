<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 

<style> 
  body {
    background-image: url('./img/hpbanner.png');
    background-repeat: no repeat ; 
  }
</style>

<body>
    <title> Quick Rail | Forms Page </title> 
        <h1 id="form-head"> Input Forms </h1> 
        <div class="something left" > 
            <a href="./forms/station_form.php">Station</a> 
            <a href="./forms/train.php">Train</a> 
            <a href="./forms/passenger.php">Passenger</a> 
            <a href="./forms/regional_form.php">Regional</a> 
        </div> 
        <div class="something main" > 
            <a href="./forms/longdist.php">Long Distance</a> 
            <a href="./schedule.php">Schedule</a> 
            <a href="./forms/route_form.php">Route</a> 
            <a href="./uni.php">Uni Student</a> 
        </div> 
        <div class="something right"> 
            <a href="./school.php">School Student</a> 
            <a href="./adult.php">Adult Worker</a> 
            <a href="./route.php">Route Path</a> 
            <a>One more?</a> 
        </div> 
   
</body> 
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br>
    
<?php 
    include('./footer.php'); 
?>