<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 

<title> Quick Rail | Forms Page </title> 
    <h1 id="form-head"> Input Forms </h1> 
    <div class="something left" > 
        <a href="./route.php">Route Path</a> 
        <a href="./train.php">Train</a> 
        <a href="./passenger.php">Passenger</a> 
        <a href="./regional.php">Regional</a> 
    </div> 
    <div class="something main" > 
        <a href="./l_dist.php">Long Distance</a> 
        <a href="./schedule.php">Schedule</a> 
        <a href="./route.php">Route</a> 
        <a href="./uni.php">Uni Student</a> 
    </div> 
    <div class="something right"> 
        <a href="./school.php">School Student</a> 
        <a href="./adult.php">Adult Worker</a> 
        <a href="./station.php">Station</a> 
        <a>One more?</a> 
    </div> 
   
   
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
<?php 
    include('./footer.php'); 
?>