<?php
    include('./header.php');
    echo '<h3>"Error: " . $sql . "<br>" . mysqli_error($conn)</h3>';
  </style>';
    include('./footer.php')
?>