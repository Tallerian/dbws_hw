<?php include 'header.php' ?>
<!DOCTYPE html>
<html>
<head>

  <div id="registration-form">
      <div class='fieldset'>
        <legend>Passenger Form!</legend>
        <form action="passenger_result.php" method="post" >
          <div class='row'>
            <label for="s_name">Departure</label>
            <div class="custom-select">
                <select id="s_name" name="dep">
                  <option value="Bremen-HBF" selected>Bremen-HBF</option>
                  <option value="Hamburg-HBF">Hamburg-HBF</option>
                  <option value="Achim">Achim</option>
                  <option value="Bochum-HBF">Bochum-HBF</option>
                  <option value="Hamburg-HBF">Bremen-Oslebshausen</option>
                  <option value="Hamburg-HBF">Bremen-St.Magnus</option>
                </select>
            </div>

            <div class='row'>
                <label for="s_name">Arrival</label>
                <div class="custom-select">
                    <select id="s_name" name="arr">
                      <option value="Bremen-HBF" selected>Bremen-HBF</option>
                      <option value="Hamburg-HBF">Hamburg-HBF</option>
                      <option value="Achim">Achim</option>
                      <option value="Bochum-HBF">Bochum-HBF</option>
                      <option value="Hamburg-HBF">Bremen-Oslebshausen</option>
                      <option value="Hamburg-HBF">Bremen-St.Magnus</option>
                    </select>
                </div>
            </div>
            
          </div>
          <input type="submit" value="Register">
        </form>
      </div>
    </div>

    <?php include '../footer.php' ?>
    
</body>

</html>