<!DOCTYPE html>
<?php include 'header.php' ?>
<html>
<head>
    <div id="registration-form">
        <div class='fieldset'>
          <legend>Schedule</legend>
          <form action="" method="post" >
            
            <div class='row'>
              <label for='firstname'>Existing Train ID</label>
              <input type="text" placeholder="Train ID" name= "trainID" >
            </div>

            <div class='row'>
              <label for="studentid">Departure time:</label>
              <input type="time" id="start" name="dep"min="09:00" max="18:00" required>
            </div>

            <div class='row'>
                <label for="studentid">Arrival time:</label>
                <input type="time" id="end" name="arr"min="09:00" max="18:00" required>
            </div>
            
            <input type="submit" value="Search">
          </form>
        </div>
      </div>

      <?php include '../footer.php' ?>
</body>

</html>