<!DOCTYPE html>
<?php include 'header.php' ?>
<html>
<head>
    <div id="registration-form">
        <div class='fieldset'>
          <legend>Schedule</legend>
          <form action="schedule_insert.php" method="post" >
            
            <div class='row'>
              <label for='firstname'>Existing Train ID</label>
              <input type="text" placeholder="Train ID" name= "trainid">
            </div>

            <div class='row'>
              <label for="studentid">Departure time:</label>
              <input type="time" id="start" name="dep" >
            </div>

            <div class='row'>
                <label for="studentid">Arrival time:</label>
                <input type="time" id="end" name="arr" >
            </div>
            
            <input type="submit" value="Search">
          </form>
        </div>
      </div>

      <?php include '../footer.php' ?>
</body>

</html>