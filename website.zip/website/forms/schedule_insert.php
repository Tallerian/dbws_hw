<?php

include ('../connect.php');
$train_id = filter_input(INPUT_POST, "trainid", FILTER_VALIDATE_INT);
$dep = $_POST["dep"];
$arr = $_POST["arr"];

if(empty($train_id) || $dep == $arr){
  echo"Please Enter valid data";
  include ("schedule_form.php");
  exit();
}

else{
  include('./header.php');

  $check1 = $connect-> query("SELECT train_id FROM train WHERE train_id = $train_id;");
  if($check1->num_rows < 1){
    echo"<p>checking if success</p>";
    echo"<p>Train ID non existant please check registered train then enter their ID for registering route</p>";
    include 'schedule_form.php';
    exit();
  }

  $sql = "INSERT INTO schedule (train_id, departure_time, arrival_time) VALUES (?,?,?);";

  $stmt = mysqli_stmt_init($connect);

  if(!mysqli_stmt_prepare($stmt, $sql)){
    die(mysqli_error($connect));
  }

  mysqli_stmt_bind_param($stmt, "sss", $train_id, $dep, $arr);

  mysqli_stmt_execute($stmt);

  echo "<p>Hello it was successful</p>";

}



?>