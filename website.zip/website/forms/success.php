<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 
<html> 
    <title> Quick Rail | Success  </title> 
    <p> Your data was inserted successfully </p> 
    <a href="./train.php" style="color:blue"> Insert Another Entry </a> <br>
    <a href="../forms.php" style="color:blue"> Go Back </a>


<?php 
    include('./footer.php'); 
?>