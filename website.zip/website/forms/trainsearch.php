<?php 
    include 'header.php';
?>

<!DOCTYPE html> 
<html> 
    <style> 
      body {
        background-image: url('../img/Background_1.jpg');
        background-repeat: no-repeat ; 
        background-size: cover;
      }
    </style>
    </style>
    <div id="registration-form">
        <div class='fieldset'>
          <legend>Train Search!</legend>
          <form action="trainsearch1.php" method="post">
            <div class='row'>
              <label for="train">Train Station</label>
              <div class="custom-select">
                  <select id="train" name="train">
                    <option value="long_Dist">Long Distance</option>
                    <option value="regional">Regional</option>
                  </select>
              </div>
            </div>
            <input type="submit" value="Search For trains" name="submit">
          </form>
        </div>
      </div>


<?php 
    include '../footer.php';
?>

