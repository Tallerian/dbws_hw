<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./styles.css">
  </head>
  <body>
    <header>
      <div class="brand"><a href="./index.php">Rail Link</a></div>
      <nav>
        <ul>
          <li><a href="./index.php">Home</a></li>
          <li><a href="./explore.php">Explore</a></li>
          <li><a href="./contact.php">Contact</a></li>
          <li class="form_link"><a href="./forms.php" >Forms</a></li>
        </ul>
      </nav>
      <div class="icon" onclick="toggleMobileMenu(this)">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <ul class="mobile-menu">
          <li><a href="/home">Home</a></li>
          <li><a href="/products">Products</a></li>
          <li><a href="/about">About</a></li>
          <li id="login"><a href="/login" >Login</a></li>
          <li id="signup"><a href="/signup">Signup</a></li>
        </ul>
      </div>
    </header>
    <script src="index.js"></script>

