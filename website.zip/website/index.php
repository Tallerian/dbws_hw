<?php 
    include('./header.php'); 
    if(isset($_POST['submit'])){
        $error = false; 
        if(!$_POST['name']){ 
            echo "Please insert name"; 
            $error = true; 
        }
        if(!$_POST['origin']){ 
            echo "<br>Please insert origin"; 
            $error = true; 
            
        }
        if(!$_POST['dest']){ 
            echo "<br>Please insert destination"; 
            $error = true; 
        }
        if($error == false){ 
            $dep = $_POST['origin']; 
            $arr = $_POST['dest']; 
            $sql = "SELECT train_name, p_name FROM train, passenger, route_path, route
            WHERE '$dep' = route_path.s_name AND route_path.route_id = route.route_id AND route.train_id = train.train_id
            UNION
            SELECT train_name, p_name FROM train, passenger, route_path, route
            WHERE '$arr' = route_path.s_name AND route_path.route_id = route.route_id AND route.train_id = train.train_id;";
            $result = $connect-> query($sql);

            if($result->num_rows > 0){
                //output data of each row
                while($row = $result->fetch_assoc()) {
                    echo"<div class='row'>";
                    echo "<p> Train ". $row["train_name"];
                    echo "</div>";
                }
            }else{
                echo "0 results";
            }
        }
    }

?>

<!DOCTYPE html> 

<style> 
  body {
    background-image: url('./img/hpbanner.png');
    background-repeat: no-repeat ; 
    background-size: cover;
  }
</style>

<html> 
    <title> Quick Rail | Home Page </title> 
    <div class="homepage">
        <div id="registration-form">
            <div class='fieldset'>
            <legend>Find your Journey!</legend>
            <form action="index.php" method="POST" >
                <div class='row' >
                    <label for='name'>Full Name</label><br>
                    <input type="text" placeholder="Full Name" id='name' data-required="true" name="name">
                </div>
                <div class='row'>
                    <label for='origin'>Origin </label><br>
                    <input type="text" placeholder="Origin" id='origin' data-required="true" name="origin">
                </div>
                <div class='row'>
                    <label for='destination'>Destination</label><br> 
                    <input type="text" placeholder="Destination" id='origin' data-required="true" name="dest">
                </div>
                <br>
                <div class='row'> 
                    <label for='date'>Date</label> <br> 
                    <input placeholder="date" type="date" id='date'>
                </div>
                    <input type="submit" value="Search" name="submit">
            </form>
            </div>
        </div>
    </div>
<?php 
    include('./footer.php'); 
?>