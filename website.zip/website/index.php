<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 

<html> 
    <title> Quick Rail | Home Page </title> 
    <div class="homepage">
        <div id="registration-form">
            <div class='fieldset'>
            <legend>Find your Journey!</legend>
            <form action="index.html" method="GET" >
                <div class='row' >
                    <label for='name'>Full Name</label><br>
                    <input type="text" placeholder="Full Name" id='name' data-required="true">
                </div>
                <div class='row'>
                    <label for='origin'>Origin </label><br>
                    <input type="text" placeholder="Origin" id='origin' data-required="true">
                </div>
                <div class='row'>
                    <label for='destination'>Destination</label><br>
                    <input type="text" placeholder="Destination" id='origin' data-required="true">
                </div>
                <br>
                <div class='row'> 
                    <label for='date'>Date</label> <br> 
                    <input placeholder="date" type="date" id='date'>
                </div>
                    <input type="submit" value="Search">
            </form>
            </div>
        </div>
    </div>
<?php 
    include('./footer.php'); 
?>