<?php 
    include('./header.php'); 
?>

<!DOCTYPE html> 
<html> 
    <title> Quick Rail | Success  </title> 
    <p> Your data was inserted successfully </p> 
    <a href="./route.php"> Go back </a>


<?php 
    include('./footer.php'); 
?>